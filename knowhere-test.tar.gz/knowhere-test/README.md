# Knowhere Tests

## Brief
There are two sets of test:
1. basic test
- check common APIs Type()/Count()/Dim()/Size()
- check result ids filled with -1 when NB is small
- check build params
- check search params

2. function test
- common check
  - check build index
  - check save and load index
  - check search and recall
  - check range search and recall
  - check get vector
- bitset check
  - check search with bitset
  - check range search with bitset
- multi-thread check
  - check search multi thread
  - check range search multi thread

## Prerequisite
1. install python3.11
2. install dependencies
```bash
cd knowhere-test/tests
cat requirements.txt | xargs -n 1 pip3 install
```

## Run
1. download or mount following datasets to `RAND_DATA_DIR` which is defined in `fbin_util.py`
```bash
(knowhere-test)  ~/vec/Data/fbin/rand/ ll
total 30084
drwxrwxr-x 2 caiyd caiyd    4096 11月 30 18:58 ./
drwxrwxr-x 4 caiyd caiyd    4096 12月 26 11:08 ../
-rw-rw-r-- 1 caiyd caiyd 5120008 11月 30 17:34 rand-128-base.fbin
-rw-rw-r-- 1 caiyd caiyd 4000008 11月 30 17:34 rand-128-cosine-gt.fbin
-rw-rw-r-- 1 caiyd caiyd 4000008 11月 30 17:34 rand-128-ip-gt.fbin
-rw-rw-r-- 1 caiyd caiyd 4000008 11月 30 17:34 rand-128-l2-gt.fbin
-rw-rw-r-- 1 caiyd caiyd   51208 11月 30 17:34 rand-128-query.fbin
-rw-rw-r-- 1 caiyd caiyd   95020 11月 30 17:49 rand-128-range-cosine-gt.fbin
-rw-rw-r-- 1 caiyd caiyd   83716 11月 30 17:49 rand-128-range-ip-gt.fbin
-rw-rw-r-- 1 caiyd caiyd   79708 11月 30 17:48 rand-128-range-l2-gt.fbin
-rw-rw-r-- 1 caiyd caiyd 5120008 11月 30 17:35 rand-4096-base.fbin
-rw-rw-r-- 1 caiyd caiyd 4000008 11月 30 17:35 rand-4096-hamming-gt.fbin
-rw-rw-r-- 1 caiyd caiyd 4000008 11月 30 17:35 rand-4096-jaccard-gt.fbin
-rw-rw-r-- 1 caiyd caiyd   51208 11月 30 17:35 rand-4096-query.fbin
-rw-rw-r-- 1 caiyd caiyd   80700 11月 30 17:48 rand-4096-range-hamming-gt.fbin
-rw-rw-r-- 1 caiyd caiyd   84172 11月 30 17:48 rand-4096-range-jaccard-gt.fbin
```
2. install the latest pyknowhere
3. run the commands below:
```bash
cd knowhere-test/tests/
pytest -v [-m L0|L2|gpu]
```

