import config
import constants
from constants import IndexType, MetricType, BuildParam, SearchParam
import json
import knowhere
import pytest
import utils
import numpy as np
from bfloat16 import bfloat16

# const params
DIM = 128
NB = 20
NQ = 10
TOPK = 100

# IVF build params
DEFAULT_NLIST = 128
MIN_NLIST = 1
MAX_NLIST = 65536

DEFAULT_PQ_M = 32
MIN_PQ_M = 1
MAX_PQ_M = 65536
MIN_RAFT_PQ_M = 0
MAX_RAFT_PQ_M = 65536

DEFAULT_NBITS = 8
MIN_NBITS = 1
MAX_NBITS = 64
MIN_RAFT_NBITS = 4
MAX_RAFT_NBITS = 8

# IVF_FLAT_CC build params
DEFAULT_SSIZE = 48
MIN_SSIZE = 32
MAX_SSIZE = 2048

# IVF search params
DEFAULT_NPROBE = 8
MIN_NPROBE = 1
MAX_NPROBE = 65536

DEFAULT_RAFT_IVF_FLAT_TOPK = 10
MIN_RAFT_IVF_FLAT_TOPK = 1
MAX_RAFT_IVF_FLAT_TOPK = 256

DEFAULT_RAFT_IVF_PQ_TOPK = 10
MIN_RAFT_IVF_PQ_TOPK = 1
MAX_RAFT_IVF_PQ_TOPK = 1024

# HNSW build params
DEFAULT_HNSW_M = 30
MIN_HNSW_M = 2
MAX_HNSW_M = 2048

DEFAULT_EFCONSTRUCTION = 360
MIN_EFCONSTRUCTION = 1

# HNSW search params
DEFAULT_EF = 360
MIN_EF = 1

# diskann build params
DEFAULT_MAX_DEGREE = 48
MIN_MAX_DEGREE = 1
MAX_MAX_DEGREE = 2048

MIN_SEARCH_LIST_SIZE = 1
MIN_PQ_CODE_BUDGET_GB = 0
MIN_BUILD_DRAM_BUDGET_GB = 0

DEFAULT_SEARCH_CACHE_BUDGET_GB = 0
MIN_SEARCH_CACHE_BUDGET_GB = 0

# diskann search params
DEFAULT_BEAMWIDTH = 8
MIN_BEAMWIDTH = 1
MAX_BEAMWIDTH = 128

# diskann range search params
DEFAULT_MIN_K = 100
MIN_MIN_K = 1

DEFAULT_FILTER_THRESHOLD = -1.0
MIN_FILTER_THRESHOLD = -1.0
MAX_FILTER_THRESHOLD = 1.0


def check_build_index(index, xb, cfg):
    xb_dataset = knowhere.ArrayToDataSet(xb)
    s = index.Build(xb_dataset, json.dumps(cfg))
    assert knowhere.Status(s) == knowhere.Status.success


def check_build_diskann(index, cfg):
    s = index.Build(knowhere.GetNullDataSet(), json.dumps(cfg))
    assert knowhere.Status(s) == knowhere.Status.success


def check_serialize_diskann(index):
    s = index.Serialize(knowhere.GetBinarySet())
    assert knowhere.Status(s) == knowhere.Status.success


def check_deserialize_diskann(index, prepare_cfg):
    s = index.Deserialize(knowhere.GetBinarySet(), json.dumps(prepare_cfg))
    assert knowhere.Status(s) == knowhere.Status.success


def check_search_ids_and_distances(ids, distances, topk):
    assert len(distances) == NQ and len(ids) == NQ
    for i in range(NQ):
        assert len(distances[i]) == len(ids[i])
        topk = len(ids[i])
        for j in range(topk):
            assert (ids[i][j] >= 0 or ids[i][j] == -1)


def check_search_result(index, metric_type, xq, topk):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    configs = config.get_search_configs(index.Type(), metric_type, topk)
    for i in range(len(configs)):
        cfg = configs[i]
        result, s = index.Search(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
        assert knowhere.Status(s) == knowhere.Status.success

        distances, ids = knowhere.DataSetToArray(result)
        check_search_ids_and_distances(ids, distances, topk)


def check_build_param_min(index, xb, cfg, param_name, min_val):
    xb_dataset = knowhere.ArrayToDataSet(xb)

    cfg[param_name] = min_val - 1
    s = index.Build(xb_dataset, json.dumps(cfg))
    assert knowhere.Status(s) != knowhere.Status.success

    cfg[param_name] = min_val
    s = index.Build(xb_dataset, json.dumps(cfg))
    assert knowhere.Status(s) == knowhere.Status.success


def check_build_param_max(index, xb, cfg, param_name, max_val):
    xb_dataset = knowhere.ArrayToDataSet(xb)

    cfg[param_name] = max_val + 1
    s = index.Build(xb_dataset, json.dumps(cfg))
    assert knowhere.Status(s) != knowhere.Status.success

    cfg[param_name] = max_val
    s = index.Build(xb_dataset, json.dumps(cfg))
    assert knowhere.Status(s) == knowhere.Status.success


def check_diskann_build_param_min(index, cfg, param_name, min_val):
    cfg[param_name] = min_val - 1
    s = index.Build(knowhere.GetNullDataSet(), json.dumps(cfg))
    assert knowhere.Status(s) != knowhere.Status.success

    cfg[param_name] = min_val
    s = index.Build(knowhere.GetNullDataSet(), json.dumps(cfg))
    assert knowhere.Status(s) == knowhere.Status.success


def check_diskann_build_param_max(index, cfg, param_name, max_val):
    cfg[param_name] = max_val + 1
    s = index.Build(knowhere.GetNullDataSet(), json.dumps(cfg))
    assert knowhere.Status(s) != knowhere.Status.success

    cfg[param_name] = max_val
    s = index.Build(knowhere.GetNullDataSet(), json.dumps(cfg))
    assert knowhere.Status(s) == knowhere.Status.success


def check_search_param_min(index, xq, cfg, param_name, min_val):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    cfg[param_name] = min_val - 1
    s = index.Search(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
    assert knowhere.Status(s) != knowhere.Status.success

    cfg[param_name] = min_val
    _, s = index.Search(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
    assert knowhere.Status(s) == knowhere.Status.success


def check_search_param_max(index, xq, cfg, param_name, max_val):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    cfg[param_name] = max_val + 1
    s = index.Search(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
    assert knowhere.Status(s) != knowhere.Status.success

    cfg[param_name] = max_val
    _, s = index.Search(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
    assert knowhere.Status(s) == knowhere.Status.success


def check_range_search_param_min(index, xq, cfg, param_name, min_val):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    cfg[param_name] = min_val - 1
    s = index.RangeSearch(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
    assert knowhere.Status(s) != knowhere.Status.success

    cfg[param_name] = min_val
    _, s = index.RangeSearch(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
    assert knowhere.Status(s) == knowhere.Status.success


def check_range_search_param_max(index, xq, cfg, param_name, max_val):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    cfg[param_name] = max_val + 1
    s = index.RangeSearch(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
    assert knowhere.Status(s) != knowhere.Status.success

    cfg[param_name] = max_val
    _, s = index.RangeSearch(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
    assert knowhere.Status(s) == knowhere.Status.success


class TestBasic:
    ###########################################################################
    # test common APIs
    ###########################################################################
    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", constants.all_float_index_types)
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    @pytest.mark.parametrize("data_type", constants.all_float_data_types)
    def test_float_index(self, index_type, metric_type, data_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_float_vec(NB, DIM, data_type)

        idx = knowhere.CreateIndex(index_type, cur_ver, data_type)
        cfg = config.get_default_build_config(metric_type)
        check_build_index(idx, xb, cfg)

        assert idx.Type() == index_type
        assert idx.Count() == NB
        assert idx.Dim() == DIM
        assert idx.Size() > 0

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", constants.all_binary_index_types)
    @pytest.mark.parametrize("metric_type", constants.all_binary_metric_types)
    def test_binary_index(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_binary_vec(NB, DIM)

        idx = knowhere.CreateIndex(index_type, cur_ver, np.uint8)
        cfg = config.get_default_build_config(metric_type)
        check_build_index(idx, xb, cfg)

        assert idx.Type() == index_type
        assert idx.Count() == NB
        assert idx.Dim() == DIM
        assert idx.Size() > 0

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.DISKANN])
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    @pytest.mark.parametrize("data_type", constants.all_float_data_types)
    def test_disk_index(self, index_type, metric_type, data_type):
        cur_ver = knowhere.GetCurrentVersion()

        tmp_path = utils.gen_random_str("test_diskann_", 4)
        index_prefix = utils.create_index_dir(tmp_path)

        xb, xb_data_path = utils.gen_random_disk_file(tmp_path, NB, DIM, data_type)

        idx = knowhere.CreateIndex(index_type, cur_ver, data_type)
        build_cfg = config.get_diskann_build_config(metric_type, index_prefix, xb_data_path, NB, DIM)
        check_build_diskann(idx, build_cfg)

        check_serialize_diskann(idx)
        prepare_cfg = config.get_diskann_prepare_config(metric_type, index_prefix, NB, DIM)
        check_deserialize_diskann(idx, prepare_cfg)

        assert idx.Type() == index_type
        assert idx.Count() == NB
        assert idx.Dim() == DIM
        assert idx.Size() > 0

    ###########################################################################
    # test search result with small nb
    ###########################################################################
    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", constants.all_float_index_types)
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    @pytest.mark.parametrize("data_type", constants.all_float_data_types)
    def test_float_index_small_nb(self, index_type, metric_type, data_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_float_vec(NB, DIM, data_type)
        xq = xb[:NQ]

        idx = knowhere.CreateIndex(index_type, cur_ver, data_type)
        cfg = config.get_default_build_config(metric_type)
        check_build_index(idx, xb, cfg)
        check_search_result(idx, metric_type, xq, TOPK)
    
    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", constants.all_binary_index_types)
    @pytest.mark.parametrize("metric_type", constants.all_binary_metric_types)
    def test_binary_index_small_nb(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_binary_vec(NB, DIM)
        xq = xb[:NQ]

        idx = knowhere.CreateIndex(index_type, cur_ver, np.uint8)
        cfg = config.get_default_build_config(metric_type)
        check_build_index(idx, xb, cfg)
        check_search_result(idx, metric_type, xq, TOPK)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.DISKANN])
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    @pytest.mark.parametrize("data_type", constants.all_float_data_types)
    def test_disk_index_small_nb(self, index_type, metric_type, data_type):
        cur_ver = knowhere.GetCurrentVersion()

        tmp_path = utils.gen_random_str("test_diskann_", 4)
        index_prefix = utils.create_index_dir(tmp_path)

        xb, xb_data_path = utils.gen_random_disk_file(tmp_path, NB, DIM, data_type)
        xq = utils.gen_random_float_vec(NQ, DIM, data_type)

        idx = knowhere.CreateIndex(index_type, cur_ver, data_type)
        build_cfg = config.get_diskann_build_config(metric_type, index_prefix, xb_data_path, NB, DIM)
        check_build_diskann(idx, build_cfg)

        check_serialize_diskann(idx)

        prepare_cfg = config.get_diskann_prepare_config(metric_type, index_prefix, NB, DIM)
        check_deserialize_diskann(idx, prepare_cfg)
        check_search_result(idx, metric_type, xq, TOPK)

    @pytest.mark.L0
    @pytest.mark.parametrize("metric_type", constants.all_metric_types)
    def test_brute_force_search_small_nb(self, metric_type):
        xb = utils.gen_random_float_vec(NB, DIM)
        xq = xb[:NQ]

        xb_dataset = knowhere.ArrayToDataSet(xb)
        xq_dataset = knowhere.ArrayToDataSet(xq)

        cfg = config.get_flat_search_config(metric_type, TOPK)
        result, s = knowhere.BruteForceSearch(np.float32, xb_dataset, xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
        assert knowhere.Status(s) == knowhere.Status.success
        distances, ids = knowhere.DataSetToArray(result)
        check_search_ids_and_distances(ids, distances, TOPK)

    ###########################################################################
    # test build param
    ###########################################################################
    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", constants.all_ivf_index_types)
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    def test_ivf_build_param(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_float_vec(NB, DIM)
        idx = knowhere.CreateIndex(index_type, cur_ver)

        cfg = {
            BuildParam.METRIC_TYPE: metric_type,
        }
        check_build_param_min(idx, xb, cfg, BuildParam.NLIST, MIN_NLIST)
        check_build_param_max(idx, xb, cfg, BuildParam.NLIST, MAX_NLIST)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.IVF_FLAT_CC])
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    def test_ivf_flat_cc_build_param(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_float_vec(NB, DIM)
        idx = knowhere.CreateIndex(index_type, cur_ver)

        cfg = {
            BuildParam.METRIC_TYPE: metric_type,
        }
        check_build_param_min(idx, xb, cfg, BuildParam.SSIZE, MIN_SSIZE)
        check_build_param_max(idx, xb, cfg, BuildParam.SSIZE, MAX_SSIZE)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.IVF_PQ])
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    def test_ivf_pq_build_param(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_float_vec(NB, DIM)
        idx = knowhere.CreateIndex(index_type, cur_ver)

        cfg = {
            BuildParam.METRIC_TYPE: metric_type,
        }
        check_build_param_min(idx, xb, cfg, BuildParam.PQ_M, MIN_PQ_M)
        # check_build_param_max(idx, xb, cfg, BuildParam.PQ_M, MAX_PQ_M)

        check_build_param_min(idx, xb, cfg, BuildParam.NBITS, MIN_NBITS)
        check_build_param_max(idx, xb, cfg, BuildParam.NBITS, MAX_NBITS)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.BIN_IVF_FLAT])
    @pytest.mark.parametrize("metric_type", constants.all_binary_metric_types)
    def test_bin_ivf_build_param(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_binary_vec(NB, DIM)
        idx = knowhere.CreateIndex(index_type, cur_ver, np.uint8)

        cfg = {
            BuildParam.METRIC_TYPE: metric_type,
        }
        check_build_param_min(idx, xb, cfg, BuildParam.NLIST, MIN_NLIST)
        check_build_param_max(idx, xb, cfg, BuildParam.NLIST, MAX_NLIST)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.HNSW])
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    def test_hnsw_build_param(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_float_vec(NB, DIM)
        idx = knowhere.CreateIndex(index_type, cur_ver)

        cfg = {
            BuildParam.METRIC_TYPE: metric_type,
        }
        # set M=1 may cause HNSW build crash
        # check_build_param_min(idx, xb, cfg, BuildParam.HNSW_M, MIN_HNSW_M)
        check_build_param_max(idx, xb, cfg, BuildParam.HNSW_M, MAX_HNSW_M)

        check_build_param_min(idx, xb, cfg, BuildParam.EFCONSTRUCTION, MIN_EFCONSTRUCTION)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.DISKANN])
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    def test_diskann_build_param(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        dir_prefix = "test_diskann_"

        tmp_path = utils.gen_random_str(dir_prefix, 4)
        utils.create_index_dir(tmp_path)

        xb, xb_data_path = utils.gen_random_disk_file(tmp_path, NB, DIM)
        idx = knowhere.CreateIndex(index_type, cur_ver)

        cfg = {
            BuildParam.METRIC_TYPE: metric_type,
            BuildParam.DATA_PATH: xb_data_path,
            BuildParam.PQ_CODE_BUDGET_GB: 0.005,
            BuildParam.MAX_DEGREE: constants.MAX_DEGREE,
            BuildParam.SEARCH_LIST_SIZE: constants.SEARCH_LIST_SIZE,
            BuildParam.BUILD_DRAM_BUDGET_GB: constants.BUILD_DRAM_BUDGET_GB,
            BuildParam.NUM_BUILD_THREAD: constants.NUM_THREADS,
        }

        # check max_degree
        cfg[BuildParam.INDEX_PREFIX] = utils.create_index_dir(utils.gen_random_str(dir_prefix, 4))
        check_diskann_build_param_min(idx, cfg, BuildParam.MAX_DEGREE, MIN_MAX_DEGREE)

        cfg[BuildParam.INDEX_PREFIX] = utils.create_index_dir(utils.gen_random_str(dir_prefix, 4))
        check_diskann_build_param_max(idx, cfg, BuildParam.MAX_DEGREE, MAX_MAX_DEGREE)

        # check search_list_size
        cfg[BuildParam.INDEX_PREFIX] = utils.create_index_dir(utils.gen_random_str(dir_prefix, 4))
        check_diskann_build_param_min(idx, cfg, BuildParam.SEARCH_LIST_SIZE, MIN_SEARCH_LIST_SIZE)

        # check pq_code_budget_gb
        # cfg[BuildParam.INDEX_PREFIX] = utils.create_index_dir(utils.gen_random_str(dir_prefix, 4))
        # check_diskann_build_param_min(idx, cfg, BuildParam.PQ_CODE_BUDGET_GB, MIN_PQ_CODE_BUDGET_GB)

        # check build_dram_budget_gb
        # cfg[BuildParam.INDEX_PREFIX] = utils.create_index_dir(utils.gen_random_str(dir_prefix, 4))
        # check_diskann_build_param_min(idx, cfg, BuildParam.BUILD_DRAM_BUDGET_GB, MIN_BUILD_DRAM_BUDGET_GB)

        # check search_cache_budget_gb
        cfg[BuildParam.INDEX_PREFIX] = utils.create_index_dir(utils.gen_random_str(dir_prefix, 4))
        check_diskann_build_param_min(idx, cfg, BuildParam.SEARCH_CACHE_BUDGET_GB, MIN_SEARCH_CACHE_BUDGET_GB)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.GPU_IVF_PQ])
    @pytest.mark.parametrize("metric_type", [MetricType.L2, MetricType.IP])
    @pytest.mark.gpu
    @pytest.mark.skip
    def test_raft_ivf_pq_build_param(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_float_vec(NB, DIM)
        idx = knowhere.CreateIndex(index_type, cur_ver)

        cfg = {
            BuildParam.METRIC_TYPE: metric_type,
            BuildParam.NLIST: 16,
        }
        check_build_param_min(idx, xb, cfg, BuildParam.PQ_M, MIN_RAFT_PQ_M)
        # check_build_param_max(idx, xb, cfg, BuildParam.PQ_M, MAX_RAFT_PQ_M)

        check_build_param_min(idx, xb, cfg, BuildParam.NBITS, MIN_RAFT_NBITS)
        check_build_param_max(idx, xb, cfg, BuildParam.NBITS, MAX_RAFT_NBITS)

    ###########################################################################
    # test search param
    ###########################################################################
    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", constants.all_ivf_index_types)
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    def test_ivf_search_param(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_float_vec(NB, DIM)
        xq = xb[:NQ]

        idx = knowhere.CreateIndex(index_type, cur_ver)
        build_cfg = config.get_default_build_config(metric_type)
        check_build_index(idx, xb, build_cfg)

        search_cfg = {
            SearchParam.METRIC_TYPE: metric_type,
            SearchParam.TOPK: 1,
        }
        check_search_param_min(idx, xq, search_cfg, SearchParam.NPROBE, MIN_NPROBE)
        check_search_param_max(idx, xq, search_cfg, SearchParam.NPROBE, MAX_NPROBE)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.BIN_IVF_FLAT])
    @pytest.mark.parametrize("metric_type", constants.all_binary_metric_types)
    def test_bin_ivf_search_param(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_binary_vec(NB, DIM)
        xq = xb[:NQ]

        idx = knowhere.CreateIndex(index_type, cur_ver, np.uint8)
        build_cfg = config.get_default_build_config(metric_type)
        check_build_index(idx, xb, build_cfg)

        search_cfg = {
            SearchParam.METRIC_TYPE: metric_type,
            SearchParam.TOPK: 1,
        }
        check_search_param_min(idx, xq, search_cfg, SearchParam.NPROBE, MIN_NPROBE)
        check_search_param_max(idx, xq, search_cfg, SearchParam.NPROBE, MAX_NPROBE)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.HNSW])
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    def test_hnsw_search_param(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_float_vec(NB, DIM)
        xq = xb[:NQ]

        idx = knowhere.CreateIndex(index_type, cur_ver)
        build_cfg = config.get_default_build_config(metric_type)
        check_build_index(idx, xb, build_cfg)

        search_cfg = {
            SearchParam.METRIC_TYPE: metric_type,
            SearchParam.TOPK: 1,
        }
        check_search_param_min(idx, xq, search_cfg, SearchParam.EF, MIN_EF)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.DISKANN])
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    def test_diskann_search_param(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()

        tmp_path = utils.gen_random_str("test_diskann_", 4)
        index_prefix = utils.create_index_dir(tmp_path)

        xb, xb_data_path = utils.gen_random_disk_file(tmp_path, NB, DIM)
        xq = xb[:NQ]

        idx = knowhere.CreateIndex(index_type, cur_ver)
        build_cfg = config.get_diskann_build_config(metric_type, index_prefix, xb_data_path, NB, DIM)
        check_build_diskann(idx, build_cfg)

        check_serialize_diskann(idx)

        prepare_cfg = config.get_diskann_prepare_config(metric_type, index_prefix, NB, DIM)
        check_deserialize_diskann(idx, prepare_cfg)

        search_cfg = {
            SearchParam.METRIC_TYPE: metric_type,
            SearchParam.TOPK: 1,
        }

        # check beamwidth
        check_search_param_min(idx, xq, search_cfg, SearchParam.BEAMWIDTH, MIN_BEAMWIDTH)
        check_search_param_max(idx, xq, search_cfg, SearchParam.BEAMWIDTH, MAX_BEAMWIDTH)

        # check filter_threshold
        check_search_param_min(idx, xq, search_cfg, SearchParam.FILTER_THRESHOLD, MIN_FILTER_THRESHOLD)
        check_search_param_max(idx, xq, search_cfg, SearchParam.FILTER_THRESHOLD, MAX_FILTER_THRESHOLD)

        range_search_cfg = {
            SearchParam.METRIC_TYPE: metric_type,
            SearchParam.RADIUS: 0.5,
        }

        # check min_k
        check_range_search_param_min(idx, xq, range_search_cfg, SearchParam.MIN_K, MIN_MIN_K)


    @pytest.mark.L2
    @pytest.mark.parametrize("index_type", [IndexType.GPU_IVF_FLAT])
    @pytest.mark.parametrize("metric_type", [MetricType.L2, MetricType.IP])
    @pytest.mark.gpu
    def test_raft_ivf_flat_search_param(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        xb = utils.gen_random_float_vec(NB, DIM)
        xq = xb[:NQ]

        idx = knowhere.CreateIndex(index_type, cur_ver)
        build_cfg = {
            BuildParam.METRIC_TYPE: metric_type,
            BuildParam.NLIST: 16,
        }
        check_build_index(idx, xb, build_cfg)

        search_cfg = {
            SearchParam.METRIC_TYPE: metric_type,
        }
        check_search_param_min(idx, xq, search_cfg, SearchParam.TOPK, MIN_RAFT_IVF_FLAT_TOPK)
        check_search_param_max(idx, xq, search_cfg, SearchParam.TOPK, MAX_RAFT_IVF_FLAT_TOPK)

    @pytest.mark.L2
    @pytest.mark.parametrize("index_type", [IndexType.GPU_IVF_PQ])
    @pytest.mark.parametrize("metric_type", [MetricType.L2, MetricType.IP])
    @pytest.mark.gpu
    def test_raft_ivf_pq_search_param(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()

        nb = 1024
        xb = utils.gen_random_float_vec(nb, DIM)
        xq = xb[:NQ]

        idx = knowhere.CreateIndex(index_type, cur_ver)
        build_cfg = {
            BuildParam.METRIC_TYPE: metric_type,
            BuildParam.NLIST: 16,
        }
        check_build_index(idx, xb, build_cfg)

        search_cfg = {
            SearchParam.METRIC_TYPE: metric_type,
        }
        check_search_param_min(idx, xq, search_cfg, SearchParam.TOPK, MIN_RAFT_IVF_PQ_TOPK)
        check_search_param_max(idx, xq, search_cfg, SearchParam.TOPK, MAX_RAFT_IVF_PQ_TOPK)
