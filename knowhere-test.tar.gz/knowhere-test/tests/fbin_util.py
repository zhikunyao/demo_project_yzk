from constants import MetricType
import numpy as np
from bfloat16 import bfloat16

RAND_DATA_DIR = "/home/data/milvus/ann_fbin/rand/"

FLOAT_RAND_BASE = RAND_DATA_DIR + "rand-128-base.fbin"
FLOAT_RAND_QUERY = RAND_DATA_DIR + "rand-128-query.fbin"

FLOAT_RAND_L2_GT = RAND_DATA_DIR + "rand-128-l2-gt.fbin"
FLOAT_RAND_IP_GT = RAND_DATA_DIR + "rand-128-ip-gt.fbin"
FLOAT_RAND_COSINE_GT = RAND_DATA_DIR + "rand-128-cosine-gt.fbin"

FLOAT_RAND_RANGE_L2_GT = RAND_DATA_DIR + "rand-128-range-l2-gt.fbin"
FLOAT_RAND_RANGE_IP_GT = RAND_DATA_DIR + "rand-128-range-ip-gt.fbin"
FLOAT_RAND_RANGE_COSINE_GT = RAND_DATA_DIR + "rand-128-range-cosine-gt.fbin"

BINARY_RAND_BASE = RAND_DATA_DIR + "rand-4096-base.fbin"
BINARY_RAND_QUERY = RAND_DATA_DIR + "rand-4096-query.fbin"

BINARY_RAND_HAMMING_GT = RAND_DATA_DIR + "rand-4096-hamming-gt.fbin"
BINARY_RAND_JACCARD_GT = RAND_DATA_DIR + "rand-4096-jaccard-gt.fbin"

BINARY_RAND_RANGE_HAMMING_GT = RAND_DATA_DIR + "rand-4096-range-hamming-gt.fbin"
BINARY_RAND_RANGE_JACCARD_GT = RAND_DATA_DIR + "rand-4096-range-jaccard-gt.fbin"


def get_fbin_meta(fname):
    shape = np.fromfile(fname, count=2, dtype='uint32')
    return shape[0], shape[1]


def get_fbin_data(fname, data_type=np.float32):
    offset = 0
    shape = np.fromfile(fname, count=2, dtype='uint32')
    offset += 2 * 4
    if data_type == np.uint8:
        data = np.fromfile(fname, offset=offset, dtype='uint8')
        return data.reshape(shape[0], int(shape[1]/8))[:, :].copy()
    elif data_type == np.float16:
        data = np.fromfile(fname, offset=offset, dtype='float32')
        data = data.astype(np.float16)
        return data.reshape(shape[0], shape[1])[:, :].copy()
    elif data_type == bfloat16:
        data = np.fromfile(fname, offset=offset, dtype='float32')
        data = data.astype(bfloat16)
        return data.reshape(shape[0], shape[1])[:, :].copy()
    elif data_type == np.float32:
        data = np.fromfile(fname, offset=offset, dtype='float32')
        return data.reshape(shape[0], shape[1])[:, :].copy()
    

def save_fbin_data(data, fname):
    f = open(fname, "wb")
    n, d = data.shape
    np.array([n, d], dtype='uint32').tofile(f)
    data.tofile(f)
    

def get_fbin_result_meta(fname):
    shape = np.fromfile(fname, count=2, dtype='uint32')
    return shape[0].item(), shape[1].item()


def get_fbin_result_data(fname):
    offset = 0
    shape = np.fromfile(fname, count=2, dtype='uint32')

    rows, topk = shape[0], shape[1]
    cnt = rows * topk

    offset += 2 * 4
    data = np.fromfile(fname, offset=offset, count=cnt, dtype='uint32')
    ids = data.reshape(rows, topk)[:, :].copy()

    offset += cnt * 4
    data = np.fromfile(fname, offset=offset, count=cnt, dtype='float32')
    distances = data.reshape(rows, topk)[:, :].copy()

    return ids, distances


def get_fbin_range_result_meta(fname):
    offset = 0
    data = np.fromfile(fname, count=1, dtype='uint32')
    rows = data[0].item()

    offset += 4
    data = np.fromfile(fname, count=1, offset=offset, dtype='float32')
    radius = data[0].item()

    return rows, radius


def get_fbin_range_result_data(fname):
    offset = 0
    data = np.fromfile(fname, count=1, dtype='uint32')
    rows = data[0]

    offset += 4
    data = np.fromfile(fname, count=1, offset=offset, dtype='float32')
    radius = data[0]

    offset += 4
    lims = np.fromfile(fname, count=(rows+1), offset=offset, dtype='uint32')
    cnt = lims[rows]

    offset += (rows + 1) * 4
    ids = np.fromfile(fname, offset=offset, count=cnt, dtype='uint32')

    offset += cnt * 4
    distances = np.fromfile(fname, offset=offset, count=cnt, dtype='float32')

    return lims, ids, distances


def get_fbin_rand_base(metric_type):
    if metric_type in [MetricType.L2, MetricType.IP, MetricType.COSINE]:
        return FLOAT_RAND_BASE
    elif metric_type in [MetricType.HAMMING, MetricType.JACCARD]:
        return BINARY_RAND_BASE
    else:
        raise Exception("metric_type: %s not supported" % metric_type)


def get_fbin_rand_query(metric_type):
    if metric_type in [MetricType.L2, MetricType.IP, MetricType.COSINE]:
        return FLOAT_RAND_QUERY
    elif metric_type in [MetricType.HAMMING, MetricType.JACCARD]:
        return BINARY_RAND_QUERY
    else:
        raise Exception("metric_type: %s not supported" % metric_type)


def get_fbin_rand_gt(metric_type, is_range=False):
    if metric_type == MetricType.L2:
        if is_range:
            fname = FLOAT_RAND_RANGE_L2_GT
        else:
            fname = FLOAT_RAND_L2_GT
    elif metric_type == MetricType.IP:
        if is_range:
            fname = FLOAT_RAND_RANGE_IP_GT
        else:
            fname = FLOAT_RAND_IP_GT
    elif metric_type == MetricType.COSINE:
        if is_range:
            fname = FLOAT_RAND_RANGE_COSINE_GT
        else:
            fname = FLOAT_RAND_COSINE_GT
    elif metric_type == MetricType.HAMMING:
        if is_range:
            fname = BINARY_RAND_RANGE_HAMMING_GT
        else:
            fname = BINARY_RAND_HAMMING_GT
    elif metric_type == MetricType.JACCARD:
        if is_range:
            fname = BINARY_RAND_RANGE_JACCARD_GT
        else:
            fname = BINARY_RAND_JACCARD_GT
    else:
        raise Exception("metric_type: %s not supported" % metric_type)
    return fname


def get_fbin_rand_meta(metric_type):
    gt = get_fbin_rand_gt(metric_type)
    return get_fbin_result_meta(gt)


def get_fbin_rand_gt_array(metric_type):
    gt = get_fbin_rand_gt(metric_type)
    return get_fbin_result_data(gt)


def get_fbin_rand_range_meta(metric_type):
    gt = get_fbin_rand_gt(metric_type, True)
    return get_fbin_range_result_meta(gt)


def get_fbin_rand_range_gt_array(metric_type):
    gt = get_fbin_rand_gt(metric_type, True)
    return get_fbin_range_result_data(gt)
