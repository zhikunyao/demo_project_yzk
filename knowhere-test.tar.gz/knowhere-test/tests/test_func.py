import config
from config import SearchParam
import constants
from constants import IndexType, MetricType
import fbin_util
import json
import knowhere
import logging
import numpy as np
import os.path
import pytest
import random
import threading
import time
import utils
from bfloat16 import bfloat16

# const params
TOPK = 100

NLIST = 16
NPROBE = 4
PQ_M = 8
NBITS = 8
HNSW_M = 16
EFCONSTRUCTION = 200
EFS = 128

search_recall_mismatch = 0
range_search_recall_mismatch = 0


def show_time_span(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        span = end_time - start_time
        print(f"# FUNC {func.__name__} runtime: {span:.3f}s")
        print("===")
        return result
    return wrapper


@show_time_span
def check_build_index(index, metric_type, xb):
    xb_dataset = knowhere.ArrayToDataSet(xb)
    build_cfg = config.get_default_build_config(metric_type)

    logging.info(f"Start building index, index_type = {index.Type()}, metric_type = {metric_type}")
    s = index.Build(xb_dataset, json.dumps(build_cfg))
    assert knowhere.Status(s) == knowhere.Status.success


@show_time_span
def check_build_diskann(index, metric_type, index_prefix, data_path, rows, dim):
    build_cfg = config.get_diskann_build_config(metric_type, index_prefix, data_path, rows, dim)

    logging.info(f"Start building index, index_type = {index.Type()}, metric_type = {metric_type}")
    s = index.Build(knowhere.GetNullDataSet(), json.dumps(build_cfg))
    assert knowhere.Status(s) == knowhere.Status.success


@show_time_span
def check_index_save_and_load(index, ver, data_type=np.float32):
    # serialize
    binset = knowhere.GetBinarySet()
    s = index.Serialize(binset)
    assert knowhere.Status(s) == knowhere.Status.success

    # create a new index and deserialize
    index_new = knowhere.CreateIndex(index.Type(), ver, data_type)
    s = index_new.Deserialize(binset)
    assert knowhere.Status(s) == knowhere.Status.success

    return index_new


@show_time_span
def check_index_write_to_file_and_load_from_file(index, ver, data_type=np.float32):
    # serialize
    binset = knowhere.GetBinarySet()
    s = index.Serialize(binset)
    assert knowhere.Status(s) == knowhere.Status.success

    tmp_path = utils.gen_random_str("test_mmap_", 4)
    utils.create_dir(tmp_path)
    file_name = index.Type() + ".idx"
    full_path_name = os.path.join(tmp_path, file_name)
    assert knowhere.WriteIndexToDisk(binset, index.Type(), full_path_name) == True

    # create a new index and deserialize from file
    index_new = knowhere.CreateIndex(index.Type(), ver, data_type)
    s = index_new.DeserializeFromFile(full_path_name)
    assert knowhere.Status(s) == knowhere.Status.success

    return index_new


def iterator_search(index, xq, cfg, bitset):
    nq = xq.GetRows()
    topk = cfg[SearchParam.TOPK]
    its, s = index.GetAnnIterator(xq, json.dumps(cfg), bitset)
    assert knowhere.Status(s) == knowhere.Status.success
    assert len(its) == nq

    dist = np.zeros([nq, topk]).astype(np.float32)
    ids = np.zeros([nq, topk]).astype(np.int32)

    for idx, it in enumerate(its):
        cnt = 0
        while it.HasNext() and cnt < topk:
            ids[idx][cnt], dist[idx][cnt] = it.Next()
            cnt += 1
        # fill result with -1 and NaN if iterator returned less than topk results
        while cnt < topk:
            ids[idx][cnt], dist[idx][cnt] = -1, float('nan')
            cnt += 1
    return dist, ids


def check_search_distance_in_order(metric_type, ids, distances):
    def check_order(metric_type, id1, v1, id2, v2):
        if id1 == -1 or id2 == -1:
            return
        if metric_type in constants.all_positive_metric_types:
            assert v1 >= v2
        else:
            assert v1 <= v2

    assert len(distances) == len(ids)
    for i in range(len(ids)):
        assert len(distances[i]) == len(ids[i])
        topk = len(ids[i])
        for j in range(topk - 1):
            check_order(metric_type, ids[i][j], distances[i][j], ids[i][j+1], distances[i][j+1])


def check_cosine_distance_in_scope(metric_type, ids, distances):
    if metric_type != MetricType.COSINE:
        return
    assert len(distances) == len(ids)
    min_value = -1.01
    max_value = 1.01 if metric_type == IndexType.IVF_PQ else 1.03
    for i in range(len(ids)):
        assert len(distances[i]) == len(ids[i])
        topk = len(ids[i])
        for j in range(topk - 1):
            if ids[i][j] != -1:
                assert (distances[i][j] >= min_value and distances[i][j] <= max_value)


def check_search_result_unique(ids):
    for i in range(len(ids)):
        arr = []
        for j in range(len(ids[i])):
            id = ids[i][j]
            if id != -1:
                arr.append(id)
        arr_set = set(arr)
        assert len(arr_set) == len(arr)


def check_search_result(metric_type, ids, distances):
    check_search_distance_in_order(metric_type, ids, distances)
    check_search_result_unique(ids)
    check_cosine_distance_in_scope(metric_type, ids, distances)


def check_range_search_result(metric_type, radius, ids, distances):
    check_distance_in_range(metric_type, radius, ids, distances)
    check_search_result_unique(ids)
    check_cosine_distance_in_scope(metric_type, ids, distances)


def get_rand_search_recall_baseline(index_type):
    if index_type == IndexType.BIN_FLAT:
        return {MetricType.HAMMING: 0.99, MetricType.JACCARD: 0.99}
    elif index_type == IndexType.BIN_IVF_FLAT:
        return {MetricType.HAMMING: 0.99, MetricType.JACCARD: 0.99}
    elif index_type == IndexType.FLAT:
        return {MetricType.L2: 0.99, MetricType.IP: 0.99, MetricType.COSINE: 0.99}
    elif index_type in [IndexType.IVF_FLAT, IndexType.GPU_IVF_FLAT]:
        return {MetricType.L2: 0.99, MetricType.IP: 0.99, MetricType.COSINE: 0.99}
    elif index_type == IndexType.IVF_FLAT_CC:
        return {MetricType.L2: 0.99, MetricType.IP: 0.99, MetricType.COSINE: 0.99}
    elif index_type == IndexType.IVF_SQ8:
        return {MetricType.L2: 0.99, MetricType.IP: 0.99, MetricType.COSINE: 0.99}
    elif index_type in [IndexType.IVF_PQ, IndexType.GPU_IVF_PQ]:
        return {MetricType.L2: 0.77, MetricType.IP: 0.83, MetricType.COSINE: 0.75}
    elif index_type == IndexType.SCANN:
        return {MetricType.L2: 0.77, MetricType.IP: 0.82, MetricType.COSINE: 0.82}
    elif index_type == IndexType.HNSW:
        return {MetricType.L2: 0.99, MetricType.IP: 0.99, MetricType.COSINE: 0.99,
                MetricType.HAMMING: 0.98, MetricType.JACCARD: 0.99}
    elif index_type == IndexType.DISKANN:
        return {MetricType.L2: 0.975, MetricType.IP: 0.975, MetricType.COSINE: 0.975}
    else:
        raise Exception("index type: %s no baseline defined" % index_type)


@show_time_span
def check_search_and_recall(index, metric_type, xq):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    gt_ids, gt_dist = fbin_util.get_fbin_rand_gt_array(metric_type)
    _, gt_topk = fbin_util.get_fbin_rand_meta(metric_type)

    configs = config.get_search_configs(index.Type(), metric_type, gt_topk)

    recall_list = []
    recall = 0.0
    for i in range(len(configs)):
        cfg = configs[i]
        result, s = index.Search(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
        assert knowhere.Status(s) == knowhere.Status.success
        distances, ids = knowhere.DataSetToArray(result)
        check_search_result(metric_type, ids, distances)

        recall = utils.calc_recall(gt_ids, ids)
        print(index.Type(), cfg, recall)
        assert recall <= 1.0
        recall_list.append(recall)

    baseline = get_rand_search_recall_baseline(index.Type())
    assert recall >= baseline[metric_type]
    return recall_list


@show_time_span
def check_iterator_search_and_recall(index, metric_type, xq):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    gt_ids, gt_dist = fbin_util.get_fbin_rand_gt_array(metric_type)
    _, gt_topk = fbin_util.get_fbin_rand_meta(metric_type)

    configs = config.get_ann_iterator_configs(index.Type(), metric_type, gt_topk)

    recall_list = []
    recall = 0.0
    for i in range(len(configs)):
        cfg = configs[i]
        distances, ids = iterator_search(index, xq_dataset, cfg, knowhere.GetNullBitSetView())
        # iterator search cannot guarantee the distance in order
        check_search_result_unique(ids)
        check_cosine_distance_in_scope(metric_type, ids, distances)

        recall = utils.calc_recall(gt_ids, ids)
        print(index.Type(), cfg, recall)
        assert recall <= 1.0
        recall_list.append(recall)

    baseline = get_rand_search_recall_baseline(index.Type())
    assert recall >= baseline[metric_type]
    return recall_list


def check_distance_in_range(metric_type, radius, ids, distances):
    def check_in_range(id, dist):
        assert id != -1
        if metric_type in constants.all_positive_metric_types:
            assert dist > radius
        else:
            assert dist < radius

    assert len(distances) == len(ids)
    for i in range(len(ids)):
        real_k = len(ids[i])
        for j in range(real_k - 1):
            check_in_range(ids[i][j], distances[i][j])


def get_rand_range_search_recall_baseline(index_type):
    if index_type == IndexType.BIN_FLAT:
        return {MetricType.HAMMING: 1.0, MetricType.JACCARD: 1.0}
    elif index_type == IndexType.BIN_IVF_FLAT:
        return {MetricType.HAMMING: 0.07, MetricType.JACCARD: 0.28}
    elif index_type == IndexType.FLAT:
        return {MetricType.L2: 0.99, MetricType.IP: 0.99, MetricType.COSINE: 0.99}
    elif index_type == IndexType.IVF_FLAT:
        return {MetricType.L2: 0.41, MetricType.IP: 0.29, MetricType.COSINE: 0.27}
    elif index_type == IndexType.IVF_FLAT_CC:
        return {MetricType.L2: 0.41, MetricType.IP: 0.29, MetricType.COSINE: 0.27}
    elif index_type == IndexType.IVF_SQ8:
        return {MetricType.L2: 0.41, MetricType.IP: 0.29, MetricType.COSINE: 0.27}
    elif index_type == IndexType.IVF_PQ:
        return {MetricType.L2: 0.49, MetricType.IP: 0.17, MetricType.COSINE: 0.23}
    elif index_type == IndexType.SCANN:
        return {MetricType.L2: 0.075, MetricType.IP: 0.008, MetricType.COSINE: 0.0075}
    elif index_type == IndexType.HNSW:
        return {MetricType.L2: 0.99, MetricType.IP: 0.99, MetricType.COSINE: 0.98,
                # MetricType.HAMMING: 0.99, MetricType.JACCARD: 0.99}
                # reduce recall for HNSW_CARDINAL
                MetricType.HAMMING: 0.95, MetricType.JACCARD: 0.97}
    elif index_type == IndexType.DISKANN:
        return {MetricType.L2: 0.985, MetricType.IP: 0.985, MetricType.COSINE: 0.98}
    else:
        raise Exception("index type: %s no baseline defined" % index_type)


@show_time_span
def check_range_search_and_recall(index, metric_type, xq):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    _, radius = fbin_util.get_fbin_rand_range_meta(metric_type)
    gt_lims, gt_ids, gt_dist = fbin_util.get_fbin_rand_range_gt_array(metric_type)

    configs = config.get_range_search_configs(index.Type(), metric_type, radius)
    recall_list = []
    for i in range(len(configs)):
        cfg = configs[i]
        result, s = index.RangeSearch(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
        assert knowhere.Status(s) == knowhere.Status.success

        distances, ids = knowhere.RangeSearchDataSetToArray(result)
        check_range_search_result(metric_type, radius, ids, distances)

        recall = utils.calc_range_recall(gt_ids, gt_lims, ids)
        print(index.Type(), cfg, recall)
        assert recall <= 1.0
        recall_list.append(recall)

    baseline = get_rand_range_search_recall_baseline(index.Type())
    assert recall >= baseline[metric_type]
    return recall_list


def verify_raw_vector(raw_vec, train_vec, ids):
    for i in range(len(raw_vec)):
        res_vec = raw_vec[i]
        gt_vec = train_vec[ids[i]]
        assert res_vec.all() == gt_vec.all()


@show_time_span
def check_get_vector(index, metric_type, xb, data_type=np.float32):
    if not index.HasRawData(metric_type):
        return

    rows = xb.shape[0]
    ids_array = np.arange(rows, dtype=np.int32)
    np.random.shuffle(ids_array)

    # only check first 10 ids
    ids = ids_array[:10]
    ids_dataset = knowhere.ArrayToDataSet(ids)
    result, _ = index.GetVectorByIds(ids_dataset)
    if data_type == np.float16:
        raw_data = knowhere.GetFloat16VectorDataSetToArray(result)
    elif data_type == bfloat16:
        raw_data = knowhere.GetBFloat16VectorDataSetToArray(result)
    else:
        raw_data = knowhere.GetVectorDataSetToArray(result)

    verify_raw_vector(raw_data, xb, ids)


@show_time_span
def check_get_binary_vector(index, metric_type, xb):
    if not index.HasRawData(metric_type):
        return

    rows = xb.shape[0]
    ids_array = np.arange(rows, dtype=np.int32)
    np.random.shuffle(ids_array)

    # only check first 10 ids
    ids = ids_array[:10]
    ids_dataset = knowhere.ArrayToDataSet(ids)
    result, _ = index.GetVectorByIds(ids_dataset)
    raw_data = knowhere.GetBinaryVectorDataSetToArray(result)

    verify_raw_vector(raw_data, xb, ids)


def get_valid_ids(ids):
    valid_num = 0
    for id in ids:
        if id != -1:
            valid_num += 1
    valid_ids = np.zeros(valid_num, dtype=np.int32)
    for i in range(len(ids)):
        if ids[i] != -1:
            valid_ids[i] = ids[i]
    return valid_ids


# return True if "vec" is subset of each element of "vec_arr"
def is_subset(vec, vec_arr):
    a = vec
    for i in range(len(vec_arr)):
        b = vec_arr[i]
        assert len(a) == len(b)
        for j in range(len(a)):
            assert (a[j] & b[j]) == a[j]


# return True if "vec" is superset of each element of "vec_arr"
def is_superset(vec, vec_arr):
    a = vec
    for i in range(len(vec_arr)):
        b = vec_arr[i]
        assert len(a) == len(b)
        for j in range(len(a)):
            assert (a[j] & b[j]) == b[j]


@show_time_span
def check_search_for_structure(index, metric_type, xq):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    cfg = config.get_flat_search_config(metric_type, TOPK)
    result, s = index.Search(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
    assert knowhere.Status(s) == knowhere.Status.success

    _, res_ids = knowhere.DataSetToArray(result)
    for i in range(len(res_ids)):
        valid_ids = get_valid_ids(res_ids[i])
        if len(valid_ids) == 0:
            continue
        ids_dataset = knowhere.ArrayToDataSet(valid_ids)
        result, _ = index.GetVectorByIds(ids_dataset)
        raw_data = knowhere.GetBinaryVectorDataSetToArray(result)
        if metric_type == MetricType.SUBSTRUCTURE:
            is_subset(xq[i], raw_data)
        else:
            is_superset(xq[i], raw_data)


def get_valid_id_set(ids):
    s = set()
    for tmp_ids in ids:
        for id in tmp_ids:
            if id != -1:
                s.add(id)
    return s


def set_bitset(bs, ids):
    for tmp_ids in ids:
        for id in tmp_ids:
            if id != -1:
                bs.SetBit(int(id))


@show_time_span
def check_search_with_bitset(index, metric_type, xq):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    configs = config.get_search_configs(index.Type(), metric_type, TOPK)
    cfg_str = json.dumps(configs[-1])

    delete_ids_set = set()
    bitset = knowhere.CreateBitSet(index.Count())

    for _ in range(3):
        result, s = index.Search(xq_dataset, cfg_str, bitset.GetBitSetView())
        assert knowhere.Status(s) == knowhere.Status.success
        distances, ids = knowhere.DataSetToArray(result)
        check_search_result(metric_type, ids, distances)

        # deleted ids should not been searched out again
        ids_set = get_valid_id_set(ids)
        for id in ids_set:
            assert id not in delete_ids_set
        delete_ids_set = delete_ids_set.union(ids_set)

        # set bitset for all searched ids
        set_bitset(bitset, ids)


@show_time_span
def check_iterator_search_with_bitset(index, metric_type, xq):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    configs = config.get_ann_iterator_configs(index.Type(), metric_type, TOPK)
    cfg = configs[-1]

    delete_ids_set = set()
    bitset = knowhere.CreateBitSet(index.Count())

    for _ in range(3):
        distances, ids = iterator_search(index, xq_dataset, cfg, bitset.GetBitSetView())
        # iterator search cannot guarantee the distance in order
        check_search_result_unique(ids)
        check_cosine_distance_in_scope(metric_type, ids, distances)

        # deleted ids should not been searched out again
        ids_set = get_valid_id_set(ids)
        for id in ids_set:
            assert id not in delete_ids_set
        delete_ids_set = delete_ids_set.union(ids_set)

        # set bitset for all searched ids
        set_bitset(bitset, ids)


@show_time_span
def check_range_search_with_bitset(index, metric_type, xq):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    _, radius = fbin_util.get_fbin_rand_range_meta(metric_type)

    configs = config.get_range_search_configs(index.Type(), metric_type, radius)
    cfg_str = json.dumps(configs[-1])

    result, s = index.RangeSearch(xq_dataset, cfg_str, knowhere.GetNullBitSetView())
    assert knowhere.Status(s) == knowhere.Status.success
    dist, ids = knowhere.RangeSearchDataSetToArray(result)
    check_range_search_result(metric_type, radius, ids, dist)

    delete_ids_set = get_valid_id_set(ids)

    # global bitset
    bitset = knowhere.CreateBitSet(index.Count())

    # set bitset for all searched ids
    set_bitset(bitset, ids)

    # do range search again
    result, s = index.RangeSearch(xq_dataset, cfg_str, bitset.GetBitSetView())
    assert knowhere.Status(s) == knowhere.Status.success
    dist, ids = knowhere.RangeSearchDataSetToArray(result)
    check_range_search_result(metric_type, radius, ids, dist)

    # deleted ids should not been searched out again
    for id in get_valid_id_set(ids):
        assert id not in delete_ids_set


@show_time_span
def check_search_multi_thread(index, metric_type, xq):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    gt_ids, gt_dist = fbin_util.get_fbin_rand_gt_array(metric_type)
    _, gt_topk = fbin_util.get_fbin_rand_meta(metric_type)
    assert TOPK <= gt_topk

    configs = config.get_search_configs(index.Type(), metric_type, TOPK)

    # HNSW and DISKANN cache cause small recall diff for the 2nd search, so do search twice
    if index.Type() in [IndexType.HNSW, IndexType.DISKANN]:
        check_search_and_recall(index, metric_type, xq)
    gt_recalls = check_search_and_recall(index, metric_type, xq)

    def check_search_with_config(cfg, gt_recall):
        result, s = index.Search(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
        assert knowhere.Status(s) == knowhere.Status.success
        _, ids = knowhere.DataSetToArray(result)

        recall = utils.calc_recall(gt_ids, ids)
        if recall != gt_recall:
            global search_recall_mismatch
            search_recall_mismatch += 1

    thread_list = []
    for i in range(constants.MAX_THREAD_NUM):
        rand_num = random.randrange(len(configs))
        t = threading.Thread(target=check_search_with_config, args=(configs[rand_num], gt_recalls[rand_num]))
        t.start()
        thread_list.append(t)
    for t in thread_list:
        t.join()

    time.sleep(1)
    assert search_recall_mismatch == 0


@show_time_span
def check_iterator_search_multi_thread(index, metric_type, xq):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    gt_ids, gt_dist = fbin_util.get_fbin_rand_gt_array(metric_type)
    _, gt_topk = fbin_util.get_fbin_rand_meta(metric_type)
    assert TOPK <= gt_topk

    configs = config.get_ann_iterator_configs(index.Type(), metric_type, TOPK)

    # HNSW and DISKANN cache cause small recall diff for the 2nd search, so do search twice
    if index.Type() in [IndexType.HNSW, IndexType.DISKANN]:
        check_iterator_search_and_recall(index, metric_type, xq)
    gt_recalls = check_iterator_search_and_recall(index, metric_type, xq)

    def check_search_with_config(cfg, gt_recall):
        _, ids = iterator_search(index, xq_dataset, cfg, knowhere.GetNullBitSetView())
        recall = utils.calc_recall(gt_ids, ids)
        if recall != gt_recall:
            global search_recall_mismatch
            search_recall_mismatch += 1

    thread_list = []
    for i in range(constants.MAX_THREAD_NUM):
        rand_num = random.randrange(len(configs))
        t = threading.Thread(target=check_search_with_config, args=(configs[rand_num], gt_recalls[rand_num]))
        t.start()
        thread_list.append(t)
    for t in thread_list:
        t.join()

    time.sleep(1)
    assert search_recall_mismatch == 0


@show_time_span
def check_range_search_multi_thread(index, metric_type, xq):
    xq_dataset = knowhere.ArrayToDataSet(xq)

    _, radius = fbin_util.get_fbin_rand_range_meta(metric_type)
    gt_lims, gt_ids, gt_dist = fbin_util.get_fbin_rand_range_gt_array(metric_type)

    configs = config.get_range_search_configs(index.Type(), metric_type, radius)

    # HNSW and DISKANN cache cause small recall diff for the 2nd search, so do search twice
    if index.Type() in [IndexType.HNSW, IndexType.DISKANN]:
        check_range_search_and_recall(index, metric_type, xq)
    gt_recalls = check_range_search_and_recall(index, metric_type, xq)

    def check_range_search_with_config(cfg, gt_recall):
        result, _ = index.RangeSearch(xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
        distances, ids = knowhere.RangeSearchDataSetToArray(result)
        recall = utils.calc_range_recall(gt_ids, gt_lims, ids)
        if recall != gt_recall:
            global range_search_recall_mismatch
            range_search_recall_mismatch += 1

    thread_list = []
    for i in range(constants.MAX_THREAD_NUM):
        rand_num = random.randrange(len(configs))
        t = threading.Thread(target=check_range_search_with_config, args=(configs[rand_num], gt_recalls[rand_num]))
        t.start()
        thread_list.append(t)
    for t in thread_list:
        t.join()

    time.sleep(1)
    assert range_search_recall_mismatch == 0


class TestFunc:
    ###########################################################################
    # test general operations, including:
    #   1. Build
    #   2. Serialize/Deserialize
    #   3. Search/RangeSearch/GetVectorByIds
    #   4. Search/RangeSearch with/wo bitset
    #   5. Search/RangeSearch multi-thread
    ###########################################################################
    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", constants.all_float_index_types)
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    @pytest.mark.parametrize("data_type", constants.all_float_data_types)
    def test_float_index(self, index_type, metric_type, data_type):
        cur_ver = knowhere.GetCurrentVersion()

        xb = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_base(metric_type), data_type)
        xq = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_query(metric_type), data_type)

        # create index and build
        idx_tmp = knowhere.CreateIndex(index_type, cur_ver, data_type)
        check_build_index(idx_tmp, metric_type, xb)

        idx = check_index_save_and_load(idx_tmp, cur_ver, data_type)

        # check general operations
        check_search_and_recall(idx, metric_type, xq)
        check_range_search_and_recall(idx, metric_type, xq)
        check_get_vector(idx, metric_type, xb, data_type)

        # check bitset
        check_search_with_bitset(idx, metric_type, xq)
        check_range_search_with_bitset(idx, metric_type, xq)

        # check multi-thread
        check_search_multi_thread(idx, metric_type, xq)
        check_range_search_multi_thread(idx, metric_type, xq)

        check_range_search_multi_thread(idx, metric_type, xq)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", constants.all_binary_index_types)
    @pytest.mark.parametrize("metric_type", constants.all_binary_metric_types)
    def test_binary_index(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()

        xb = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_base(metric_type), np.uint8)
        xq = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_query(metric_type), np.uint8)

        # create index and build
        idx_tmp = knowhere.CreateIndex(index_type, cur_ver, np.uint8)
        check_build_index(idx_tmp, metric_type, xb)

        idx = check_index_save_and_load(idx_tmp, cur_ver, np.uint8)

        # check general operations
        check_search_and_recall(idx, metric_type, xq)
        check_range_search_and_recall(idx, metric_type, xq)
        check_get_binary_vector(idx, metric_type, xb)

        # check bitset
        check_search_with_bitset(idx, metric_type, xq)
        check_range_search_with_bitset(idx, metric_type, xq)

        # check multi-thread
        check_search_multi_thread(idx, metric_type, xq)
        check_range_search_multi_thread(idx, metric_type, xq)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.BIN_FLAT])
    @pytest.mark.parametrize("metric_type", constants.all_structure_metric_types)
    @pytest.mark.parametrize("dim", [32, 64])
    def test_bin_flat_struct(self, index_type, metric_type, dim):
        cur_ver = knowhere.GetCurrentVersion()

        nb = 10000
        nq = 100

        xb = utils.gen_random_binary_vec(nb, dim)
        xq = xb[:nq]

        # create index and build
        idx_tmp = knowhere.CreateIndex(index_type, cur_ver, np.uint8)
        check_build_index(idx_tmp, metric_type, xb)

        idx = check_index_save_and_load(idx_tmp, cur_ver, np.uint8)

        # check search
        check_search_for_structure(idx, metric_type, xq)

        # check bitset
        check_search_with_bitset(idx, metric_type, xq)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.DISKANN])
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    @pytest.mark.parametrize("data_type", constants.all_float_data_types)
    def test_disk_index(self, index_type, metric_type, data_type):
        cur_ver = knowhere.GetCurrentVersion()

        tmp_path = utils.gen_random_str("test_diskann_", 4)
        index_prefix = utils.create_index_dir(tmp_path)

        xb_data_path = fbin_util.get_fbin_rand_base(metric_type)
        xq_data_path = fbin_util.get_fbin_rand_query(metric_type)

        rows, dim = fbin_util.get_fbin_meta(xb_data_path)
        xb = fbin_util.get_fbin_data(xb_data_path, data_type)
        xq = fbin_util.get_fbin_data(xq_data_path, data_type)
        if data_type != np.float32:
            xb_data_path = tmp_path + "/raw_data"
            fbin_util.save_fbin_data(xb, xb_data_path)

        # create index and check build time
        idx_tmp = knowhere.CreateIndex(index_type, cur_ver, data_type)
        check_build_diskann(idx_tmp, metric_type, index_prefix, xb_data_path, rows, dim)

        s = idx_tmp.Serialize(knowhere.GetBinarySet())
        assert knowhere.Status(s) == knowhere.Status.success

        # create a new index and deserialize
        idx = knowhere.CreateIndex(index_type, cur_ver, data_type)
        prepare_cfg = config.get_diskann_prepare_config(metric_type, index_prefix, rows, dim)
        idx.Deserialize(knowhere.GetBinarySet(), json.dumps(prepare_cfg))

        # do check after deserialize
        check_search_and_recall(idx, metric_type, xq)
        check_range_search_and_recall(idx, metric_type, xq)
        check_get_vector(idx, metric_type, xb, data_type)

        # check search with bitset
        check_search_with_bitset(idx, metric_type, xq)
        check_range_search_with_bitset(idx, metric_type, xq)

        # check multi-thread
        check_search_multi_thread(idx, metric_type, xq)
        check_range_search_multi_thread(idx, metric_type, xq)

    ###########################################################################
    # test general operations with mmap, including:
    #   1. Build
    #   2. Serialize/DeserializeFromFile
    #   3. Search/RangeSearch/GetVectorByIds
    #   4. Search/RangeSearch with/wo bitset
    ###########################################################################
    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", constants.all_float_index_types)
    @pytest.mark.parametrize("metric_type", [MetricType.L2])
    def test_float_index_mmap(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()

        xb = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_base(metric_type))
        xq = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_query(metric_type))

        # create index and build
        idx_tmp = knowhere.CreateIndex(index_type, cur_ver)
        check_build_index(idx_tmp, metric_type, xb)

        idx = check_index_write_to_file_and_load_from_file(idx_tmp, cur_ver)

        # check general operations
        check_search_and_recall(idx, metric_type, xq)
        check_range_search_and_recall(idx, metric_type, xq)
        check_get_vector(idx, metric_type, xb)

        # check bitset
        check_search_with_bitset(idx, metric_type, xq)
        check_range_search_with_bitset(idx, metric_type, xq)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", constants.all_binary_index_types)
    @pytest.mark.parametrize("metric_type", [MetricType.HAMMING])
    def test_binary_index_mmap(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()

        xb = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_base(metric_type), np.uint8)
        xq = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_query(metric_type), np.uint8)

        # create index and build
        idx_tmp = knowhere.CreateIndex(index_type, cur_ver, np.uint8)
        check_build_index(idx_tmp, metric_type, xb)

        idx = check_index_write_to_file_and_load_from_file(idx_tmp, cur_ver, np.uint8)

        # check general operations
        check_search_and_recall(idx, metric_type, xq)
        check_range_search_and_recall(idx, metric_type, xq)
        check_get_binary_vector(idx, metric_type, xb)

        # check bitset
        check_search_with_bitset(idx, metric_type, xq)
        check_range_search_with_bitset(idx, metric_type, xq)

    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.BIN_FLAT])
    @pytest.mark.parametrize("metric_type", [MetricType.SUBSTRUCTURE])
    @pytest.mark.parametrize("dim", [32, 64])
    def test_bin_flat_struct_mmap(self, index_type, metric_type, dim):
        cur_ver = knowhere.GetCurrentVersion()

        nb = 10000
        nq = 100

        xb = utils.gen_random_binary_vec(nb, dim)
        xq = xb[:nq]

        # create index and build
        idx_tmp = knowhere.CreateIndex(index_type, cur_ver, np.uint8)
        check_build_index(idx_tmp, metric_type, xb)

        idx = check_index_write_to_file_and_load_from_file(idx_tmp, cur_ver, np.uint8)

        # check search
        check_search_for_structure(idx, metric_type, xq)

        # check bitset
        check_search_with_bitset(idx, metric_type, xq)

    ###########################################################################
    # test brute force Search/RangeSearch
    ###########################################################################
    @pytest.mark.L0
    @pytest.mark.parametrize("metric_type", constants.all_metric_types)
    def test_brute_force(self, metric_type):
        is_binary = metric_type in constants.all_binary_metric_types
        if is_binary:
            data_type = np.uint8
        else:
            data_type = np.float32
        xb = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_base(metric_type), data_type)
        xq = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_query(metric_type), data_type)
        xb_dataset = knowhere.ArrayToDataSet(xb)
        xq_dataset = knowhere.ArrayToDataSet(xq)

        # check search
        gt_ids, gt_dist = fbin_util.get_fbin_rand_gt_array(metric_type)
        _, gt_topk = fbin_util.get_fbin_rand_meta(metric_type)
        assert TOPK <= gt_topk

        cfg = config.get_flat_search_config(metric_type, TOPK)

        result, s = knowhere.BruteForceSearch(data_type, xb_dataset, xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
        assert knowhere.Status(s) == knowhere.Status.success
        _, ids = knowhere.DataSetToArray(result)

        recall = utils.calc_recall(gt_ids, ids)
        assert recall > 0.96

        # check range search
        _, radius = fbin_util.get_fbin_rand_range_meta(metric_type)
        gt_lims, gt_ids, gt_dist = fbin_util.get_fbin_rand_range_gt_array(metric_type)

        cfg = config.get_flat_range_search_config(metric_type, radius)

        result, s = knowhere.BruteForceRangeSearch(data_type, xb_dataset, xq_dataset, json.dumps(cfg), knowhere.GetNullBitSetView())
        assert knowhere.Status(s) == knowhere.Status.success
        _, ids = knowhere.RangeSearchDataSetToArray(result)

        recall = utils.calc_range_recall(gt_ids, gt_lims, ids)
        assert recall > 0.99

    ###########################################################################
    # test Search using different SIMD
    ###########################################################################
    @pytest.mark.L0
    @pytest.mark.parametrize("simd_type", constants.all_simd_types)
    @pytest.mark.parametrize("index_type", [IndexType.IVF_FLAT, IndexType.HNSW])
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    def test_simd(self, simd_type, index_type, metric_type):
        knowhere.SetSimdType(simd_type)
        cur_ver = knowhere.GetCurrentVersion()

        xb = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_base(metric_type))
        xq = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_query(metric_type))

        # create index and check build time
        idx = knowhere.CreateIndex(index_type, cur_ver)
        check_build_index(idx, metric_type, xb)

        # check search and range search
        check_search_and_recall(idx, metric_type, xq)
        check_range_search_and_recall(idx, metric_type, xq)

    ###########################################################################
    # test version support
    ###########################################################################
    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", constants.all_float_index_types)
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    def test_version(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()
        
        # TODO: will remove after Milvus 2.5.0
        if index_type == IndexType.IVF_FLAT and metric_type == MetricType.COSINE:
            pytest.skip()

        xb = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_base(metric_type))
        xq = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_query(metric_type))

        def check_load_index_version(ver):
            # create index with ver
            idx = knowhere.CreateIndex(index_type, ver)
            check_build_index(idx, metric_type, xb)

            idx2 = check_index_save_and_load(idx, ver)

            # check search and range search behavior
            check_search_and_recall(idx2, metric_type, xq)
            check_range_search_and_recall(idx2, metric_type, xq)

        check_load_index_version(cur_ver)
        check_load_index_version(cur_ver - 1)

    ###########################################################################
    # test iterator
    ###########################################################################
    @pytest.mark.L0
    @pytest.mark.parametrize("index_type", [IndexType.HNSW])
    @pytest.mark.parametrize("metric_type", constants.all_float_metric_types)
    def test_iterator(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()

        xb = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_base(metric_type))
        xq = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_query(metric_type))

        idx = knowhere.CreateIndex(index_type, cur_ver)
        check_build_index(idx, metric_type, xb)

        check_iterator_search_and_recall(idx, metric_type, xq)
        check_iterator_search_with_bitset(idx, metric_type, xq)
        check_iterator_search_multi_thread(idx, metric_type, xq)

    @pytest.mark.L2
    @pytest.mark.parametrize("index_type", [IndexType.GPU_IVF_FLAT, IndexType.GPU_IVF_PQ])
    @pytest.mark.parametrize("metric_type", [MetricType.L2, MetricType.IP])
    @pytest.mark.gpu
    @pytest.mark.skip
    def test_gpu_index(self, index_type, metric_type):
        cur_ver = knowhere.GetCurrentVersion()

        xb = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_base(metric_type))
        xq = fbin_util.get_fbin_data(fbin_util.get_fbin_rand_query(metric_type))

        # create index and build
        idx_tmp = knowhere.CreateIndex(index_type, cur_ver)
        check_build_index(idx_tmp, metric_type, xb)

        idx = check_index_save_and_load(idx_tmp, cur_ver)

        # check general operations
        check_search_and_recall(idx, metric_type, xq)