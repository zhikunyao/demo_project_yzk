import numpy as np
from bfloat16 import bfloat16

class DataClass:
    SIFT = "sift"
    GLOVE = "glove"
    GLOVE_COSINE = "glove-cosine"
    SIFT_HAMMING = "sift-4096-hamming"
    SIFT_JACCARD = "sift-4096-jaccard"
    KNN_SSNPP256d1M = "ssnpp"

class IndexType:
    BIN_FLAT = "BIN_FLAT"
    BIN_IVF_FLAT = "BIN_IVF_FLAT"
    FLAT = "FLAT"
    IVF_FLAT = "IVF_FLAT"
    IVF_FLAT_CC = "IVF_FLAT_CC"
    IVF_SQ8 = "IVF_SQ8"
    IVF_PQ = "IVF_PQ"
    SCANN = "SCANN"
    HNSW = "HNSW"
    DISKANN = "DISKANN"
    GPU_IVF_FLAT = "GPU_RAFT_IVF_FLAT"
    GPU_IVF_PQ = "GPU_RAFT_IVF_PQ"

class MetricType:
    L2 = "L2"
    IP = "IP"
    COSINE = "COSINE"
    HAMMING = "HAMMING"
    JACCARD = "JACCARD"
    SUBSTRUCTURE = "SUBSTRUCTURE"
    SUPERSTRUCTURE = "SUPERSTRUCTURE"

class SimdType:
    AUTO = "auto"
    AVX512 = "avx512"
    AVX2 = "avx2"
    AVX = "avx"
    SSE4_2 = "sse4_2"
    GENERIC = "generic"

class BuildParam:
    METRIC_TYPE = "metric_type"
    DIM = "dim"

    # IVF build params
    NLIST = "nlist"

    # IVF_PQ build params
    PQ_M = "m"
    NBITS = "nbits"

    # IVF_FLAT_CC build params
    SSIZE = "ssize"

    # HNSW build params
    HNSW_M = "M"
    EFCONSTRUCTION = "efConstruction"

    # DISKANN build params
    DATA_PATH = "data_path"
    INDEX_PREFIX = "index_prefix"
    MAX_DEGREE = "max_degree"
    SEARCH_LIST_SIZE = "search_list_size"
    PQ_CODE_BUDGET_GB = "pq_code_budget_gb"
    BUILD_DRAM_BUDGET_GB = "build_dram_budget_gb"
    SEARCH_CACHE_BUDGET_GB = "search_cache_budget_gb"
    NUM_BUILD_THREAD = "num_build_thread"
    USE_BFS_CACHE = "use_bfs_cache"
    WARM_UP = "warm_up"


class SearchParam:
    METRIC_TYPE = "metric_type"
    TOPK = "k"
    RADIUS = "radius"
    ENABLE_MMAP = "enable_mmap"

    # IVF search params
    NPROBE = "nprobe"

    # HNSW search params
    EF = "ef"
    SEED_EF = "seed_ef"

    # DISKANN search params
    SEARCH_LIST_SIZE = "search_list_size"
    BEAMWIDTH = "beamwidth"
    NUM_THREADS = "num_threads"


    # DISKANN search params
    SEARCH_LIST_SIZE = "search_list_size"
    BEAMWIDTH = "beamwidth"
    NUM_THREADS = "num_threads"
    FILTER_THRESHOLD = "filter_threshold"
    MIN_K = "min_k"
    MAX_K = "max_k"


# Specially defined list
all_index_types = [
    IndexType.FLAT,             # 0
    IndexType.IVF_FLAT,         # 1
    IndexType.IVF_FLAT_CC,      # 2
    IndexType.IVF_SQ8,          # 3
    IndexType.IVF_PQ,           # 4
    IndexType.SCANN,            # 5
    IndexType.HNSW,             # 6
    IndexType.DISKANN,          # 7
    IndexType.BIN_FLAT,         # 8
    IndexType.BIN_IVF_FLAT,     # 9
    IndexType.GPU_IVF_FLAT,     # 10
    IndexType.GPU_IVF_PQ        # 11
]

all_float_index_types = [IndexType.FLAT, IndexType.IVF_FLAT, IndexType.IVF_FLAT_CC, IndexType.IVF_SQ8, IndexType.IVF_PQ,
                         IndexType.SCANN, IndexType.HNSW]
all_ivf_index_types = [IndexType.IVF_FLAT, IndexType.IVF_FLAT_CC, IndexType.IVF_SQ8, IndexType.IVF_PQ, IndexType.SCANN]
all_binary_index_types = [IndexType.BIN_FLAT, IndexType.BIN_IVF_FLAT, IndexType.HNSW]

all_metric_types = [MetricType.L2, MetricType.IP, MetricType.COSINE, MetricType.HAMMING, MetricType.JACCARD]
all_positive_metric_types = [MetricType.IP, MetricType.COSINE]
all_float_metric_types = [MetricType.L2, MetricType.IP, MetricType.COSINE]
all_float_data_types = [np.float32, np.float16, bfloat16]
all_binary_metric_types = [MetricType.HAMMING, MetricType.JACCARD]
all_structure_metric_types = [MetricType.SUBSTRUCTURE, MetricType.SUPERSTRUCTURE]
# AUTO must be the last one to avoid to affect other tests
all_simd_types = [SimdType.AVX512, SimdType.AVX2, SimdType.AVX, SimdType.SSE4_2, SimdType.GENERIC, SimdType.AUTO]

DEFAULT_RECALL_PRECISION = 4
MAX_THREAD_NUM = 10

# fixed nq and top_k for recall tests
NQ = 10000
TOP_K = 100

NLIST = 1024
NPROBES = [1, 2, 4, 8, 16, 32, 64, 128]
PQ_M = 8
NBITS = 8
HNSW_M = 16
EFCONSTRUCTION = 200
EFS = [128, 256, 512, 1024]
SEARCH_LIST_SIZES = [10, 20, 50, 100, 200]
RANGE_MIN_KS = [100, 150, 200]

# baselines for DISKANN
# BuildConfig
MAX_DEGREE = 56
SEARCH_LIST_SIZE = 100
NUM_THREADS = 8
SEARCH_NUM_THREADS = 8
BUILD_DRAM_BUDGET_GB = 32.0  # don't change, float type
DISK_PQ_DIMS = 0
ACCELERATE_BUILD = False
PQ_COMPRESS_RATE = 8
EXPANSION_RATE = 0.125
# L2
SEARCH_DRAM_BUDGET_GB = 0.03   # 0.00059
# IP
SEARCH_DRAM_BUDGET_GB_IP = 0.056  # 0.00093
# range search L2
SEARCH_DRAM_BUDGET_GB_RANGE = 0.12

# PrepareConfig
NUM_NODES_TO_CACHE = 10000
# num_nodes_to_cache * expansion_rate * cached_node_size /1024/1024/1024  10000*1.2*612/1024/1024/1024
SEARCH_CACHE_BUDGET_GB = 0.006839633
DATA_VOLUME = 1000000
WARM_UP = False
USE_BFS_CACHE = False
USE_BFS_CACHE_RANGE = True

# QueryConfig
BEAMWIDTH = 16
K = 100
MAX_K = 40000
# range search
BEAMWIDTH_RANGE = 8
# Evaluation Indicators
