import constants
from constants import BuildParam, SearchParam, IndexType, MetricType
import json
import utils


def get_default_build_config(metric_type):
    # use default params
    return {
        BuildParam.METRIC_TYPE: metric_type,
    }


def get_flat_build_config(metric_type):
    return get_default_build_config(metric_type)


def get_ivf_build_config(metric_type, nlist):
    cfg = get_default_build_config(metric_type)
    cfg[BuildParam.NLIST] = nlist
    return cfg


def get_ivf_pq_build_config(metric_type, nlist, m, nbits):
    cfg = get_default_build_config(metric_type)
    cfg[BuildParam.NLIST] = nlist
    cfg[BuildParam.PQ_M] = m
    cfg[BuildParam.NBITS] = nbits
    return cfg


def get_hnsw_build_config(metric_type, m, efc):
    cfg = get_default_build_config(metric_type)
    cfg[BuildParam.HNSW_M] = m
    cfg[BuildParam.EFCONSTRUCTION] = efc
    return cfg


def get_diskann_build_config(metric_type, index_prefix, data_path, rows, dim):
    pq_code_budget_gb = utils.calc_diskann_build_pq(rows, dim)
    cfg = get_default_build_config(metric_type)
    cfg[BuildParam.INDEX_PREFIX] = index_prefix
    cfg[BuildParam.DATA_PATH] = data_path
    cfg[BuildParam.PQ_CODE_BUDGET_GB] = float(pq_code_budget_gb)
    cfg[BuildParam.MAX_DEGREE] = int(constants.MAX_DEGREE)
    cfg[BuildParam.SEARCH_LIST_SIZE] = int(constants.SEARCH_LIST_SIZE)
    cfg[BuildParam.BUILD_DRAM_BUDGET_GB] = float(constants.BUILD_DRAM_BUDGET_GB)
    cfg[BuildParam.NUM_BUILD_THREAD] = int(constants.NUM_THREADS)
    return cfg


def get_diskann_prepare_config(metric_type, index_prefix, rows, dim):
    search_cache_budget_gb = utils.calc_diskann_search_cache(rows, dim)
    cfg = get_default_build_config(metric_type)
    cfg[BuildParam.INDEX_PREFIX] = index_prefix
    cfg[BuildParam.SEARCH_CACHE_BUDGET_GB] = search_cache_budget_gb
    cfg[BuildParam.USE_BFS_CACHE] = constants.USE_BFS_CACHE
    cfg[BuildParam.WARM_UP] = constants.WARM_UP
    return cfg


def get_default_search_config(metric_type, topk):
    return {
        SearchParam.METRIC_TYPE: metric_type,
        SearchParam.TOPK: topk,
        SearchParam.ENABLE_MMAP: True,
    }


def get_flat_search_config(metric_type, topk):
    return get_default_search_config(metric_type, topk)


def get_ivf_search_config(metric_type, topk, nprobe):
    cfg = get_default_search_config(metric_type, topk)
    cfg[SearchParam.NPROBE] = nprobe
    return cfg


def get_hnsw_search_config(metric_type, topk, ef):
    cfg = get_default_search_config(metric_type, topk)
    cfg[SearchParam.EF] = ef
    return cfg


# same as search config
def get_hnsw_ann_iterator_config(metric_type, topk, ef):
    cfg = get_default_search_config(metric_type, topk)
    cfg[SearchParam.EF] = ef
    return cfg


def get_diskann_search_config(metric_type, topk, search_list_size):
    cfg = get_default_search_config(metric_type, topk)
    cfg[SearchParam.SEARCH_LIST_SIZE] = search_list_size
    cfg[SearchParam.BEAMWIDTH] = constants.BEAMWIDTH
    cfg[SearchParam.NUM_THREADS] = constants.SEARCH_NUM_THREADS
    return cfg


def get_search_configs(index_type, metric_type, max_topk):
    configs = []
    topk = 10
    while topk < max_topk:
        if index_type in [IndexType.BIN_IVF_FLAT,
                          IndexType.IVF_FLAT, IndexType.IVF_FLAT_CC, IndexType.SCANN,
                          IndexType.IVF_SQ8, IndexType.IVF_PQ,
                          IndexType.GPU_IVF_FLAT, IndexType.GPU_IVF_PQ]:
            if index_type == IndexType.GPU_IVF_FLAT:
                if topk > 256:
                    break
            for nprobe in constants.NPROBES:
                configs.append(get_ivf_search_config(metric_type, topk, nprobe))
        elif index_type == IndexType.HNSW:
            for ef in constants.EFS:
                if ef < topk:
                    continue
                configs.append(get_hnsw_search_config(metric_type, topk, ef))
        elif index_type == IndexType.DISKANN:
            for size in constants.SEARCH_LIST_SIZES:
                if size < topk:
                    continue
                configs.append(get_diskann_search_config(metric_type, topk, size))
        else:
            configs.append(get_default_search_config(metric_type, topk))
        topk *= 10

    return configs


def get_ann_iterator_configs(index_type, metric_type, max_topk):
    configs = []
    # only HNSW currently supports ann iterator
    assert index_type == IndexType.HNSW
    topk = 10
    while topk < max_topk:
        for ef in constants.EFS:
            if ef < topk:
                continue
            configs.append(get_hnsw_ann_iterator_config(metric_type, topk, ef))
            topk *= 10
    return configs


def get_default_search_config(metric_type, topk):
    return {
        SearchParam.METRIC_TYPE: metric_type,
        SearchParam.TOPK: topk,
    }


def get_flat_range_search_config(metric_type, radius):
    return {
        SearchParam.METRIC_TYPE: metric_type,
        SearchParam.RADIUS: radius,
    }


def get_ivf_range_search_config(metric_type, radius):
    return {
        SearchParam.METRIC_TYPE: metric_type,
        SearchParam.RADIUS: radius,
    }


def get_hnsw_range_search_config(metric_type, radius, ef):
    return {
        SearchParam.METRIC_TYPE: metric_type,
        SearchParam.RADIUS: radius,
        SearchParam.EF: ef,
    }


def get_diskann_range_search_config(metric_type, radius, search_list_size):
    return {
        SearchParam.METRIC_TYPE: metric_type,
        SearchParam.RADIUS: radius,
        SearchParam.SEARCH_LIST_SIZE: search_list_size,
        SearchParam.BEAMWIDTH: constants.BEAMWIDTH,
        SearchParam.NUM_THREADS: constants.SEARCH_NUM_THREADS,
    }


def get_range_search_configs(index_type, metric_type, radius):
    configs = []
    if index_type in [IndexType.BIN_FLAT, IndexType.FLAT]:
        configs.append(get_flat_range_search_config(metric_type, radius))
    elif index_type in [IndexType.BIN_IVF_FLAT,
                        IndexType.IVF_FLAT, IndexType.IVF_FLAT_CC, IndexType.SCANN,
                        IndexType.IVF_SQ8, IndexType.IVF_PQ,
                        IndexType.GPU_IVF_FLAT, IndexType.GPU_IVF_PQ]:
        configs.append(get_ivf_range_search_config(metric_type, radius))
    elif index_type == IndexType.HNSW:
        for ef in constants.EFS:
            configs.append(get_hnsw_range_search_config(metric_type, radius, ef))
    elif index_type == IndexType.DISKANN:
        for size in constants.SEARCH_LIST_SIZES:
            configs.append(get_diskann_range_search_config(metric_type, radius, size))
    else:
        raise Exception("index type: %s not supported" % index_type)

    return configs
