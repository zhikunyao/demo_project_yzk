import constants
from constants import IndexType, DataClass, MetricType
import numpy as np
import os
import random
import shutil
import sklearn.preprocessing
import string
from bfloat16 import bfloat16


def normalize(metric_type, X):
    if metric_type == MetricType.IP:
        # logging.info("Set normalize for metric_type: %s" % metric_type)
        X = sklearn.preprocessing.normalize(X, axis=1, norm=MetricType.L2.lower())
        X = X.astype(np.float32)
    elif metric_type == MetricType.L2:
        X = X.astype(np.float32)
    return X


def calc_hits(gt_ids, result_ids):
    hits_sum = 0
    for i, ids in enumerate(result_ids):
        hits_sum += len(set(gt_ids[i][:ids.shape[0]]).intersection(set(ids)))
    return hits_sum


def calc_recall(gt_ids, result_ids):
    hits_sum = calc_hits(gt_ids, result_ids)
    return round(hits_sum / (result_ids.shape[0] * result_ids.shape[1]), constants.DEFAULT_RECALL_PRECISION)


def calc_range_hits(gt_ids, gt_lims, result_ids):
    hits_sum = 0
    for i, ids in enumerate(result_ids):
        truth = set(gt_ids[gt_lims[i]: gt_lims[i + 1]])
        hits_sum += len(truth.intersection(ids))
    return hits_sum


def calc_range_recall(gt_ids, gt_lims, result_ids):
    hits_sum = calc_range_hits(gt_ids, gt_lims, result_ids)
    nq = len(result_ids)
    return round(hits_sum / gt_lims[nq], constants.DEFAULT_RECALL_PRECISION)


def calc_diskann_search_cache(rows, dim):
    """
    0 allowed, smaller allowed
    # ctypes.sizeof(ctypes.c_float) * ndim * nb * 0.125 / (1024 * 1024 * 1024)
    dim * num_nodes_to_cache * ctypes.sizeof(ctypes.c_float) /1024/1024/1024* 8
    """
    data_size = rows * dim * 4 / (1 << 30)
    cache_size = data_size * constants.EXPANSION_RATE
    return cache_size


def calc_diskann_build_pq(rows, dim):
    data_size = rows * dim * 4 / (1 << 30)
    return data_size / constants.PQ_COMPRESS_RATE


def gen_random_float_vec(rows, dim, data_type = np.float32):
    if data_type == np.float16:
        return np.array(np.random.randn(rows, dim).astype(np.float16))
    elif data_type == bfloat16:
        return np.array(np.random.randn(rows, dim).astype(bfloat16))
    else:
        return np.array(np.random.randn(rows, dim).astype(np.float32))


def gen_random_binary_vec(rows, dim):
    return np.array(np.random.randint(0, (1 << 8) - 1, size=(rows, int(dim/8)), dtype=np.uint8))


def gen_random_disk_file(root_dir, rows, dims, data_type = np.float32):
    shape = np.array([rows, dims]).astype(np.uint32)
    if data_type == np.float32:
        data = np.random.uniform(1, 5, [rows, dims]).astype(np.float32)
    else:
        data = gen_random_float_vec(rows, dims, data_type)
    file_path = os.path.join(root_dir, "diskann_data")
    with open(file_path, 'w') as f:
        shape.tofile(f)
        data.tofile(f)
    f.close()
    return data, file_path


def gen_random_str(prefix, num):
    return prefix + ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(num))


def create_dir(path_name):
    if os.path.exists(path_name):
        try:
            shutil.rmtree(path_name)
        except:
            pass
    os.makedirs(path_name)


def create_index_dir(path_name):
    create_dir(path_name)
    index_prefix = os.path.join(path_name, "index")
    return index_prefix
