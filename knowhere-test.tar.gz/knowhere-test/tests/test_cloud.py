import json
import os

import knowhere
import numpy as np
import pytest

import constants
from config import get_default_build_config
from constants import BuildParam

# const params

cloud_index_file_dir = "/home/data/milvus/cloud_index_files"

# the file name rule is `dataset_metric_indextype_repo_gitcommit_version_paramkey1_paramvalue1_...[suffix]`
# for example: HNSW (siftsmall_L2_HNSW_cloud_fca569a_2_retrieve_false_searchquant_AUTO_mem.index.bin)
#              DISKANN (siftsmall_L2_DISKANN_cloud_fca569a_2_cacheratio_0.10_retrieve_false_disk.index.bin)
def list_files_with_suffix(directory, suffix):
    files_with_suffix = []

    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(suffix):
                files_with_suffix.append(os.path.join(root, file))

    return files_with_suffix


def parse_file_info(file_path, suffix):
    prefix = file_path.split(suffix)[0]

    workspace = os.path.dirname(file_path)
    file_name = os.path.basename(file_path)
    file_size = os.stat(file_path).st_size
    main_part = file_name.split(suffix)[0]

    components = main_part.split('_')

    dataset, metric, index_type, repo, tag, version = components[:6]

    key_values = components[6:]

    pairs = {}

    for i in range(0, len(key_values) - 1, 2):
        key = key_values[i]
        value = key_values[i + 1]
        pairs[key] = value

    return {
        'prefix': prefix,
        'file_size': file_size,
        "workspace": workspace,
        "dataset": dataset,
        "metric": metric,
        "index_type": index_type,
        "repo": repo,
        "tag": tag,
        "version": version,
        "key-values": pairs
    }


def gen_binary_set(index_type, file_path):
    with open(file_path, "rb") as f:
        data = np.fromfile(f, dtype=np.uint8)
    binary = knowhere.ArrayToBinary(data)
    return knowhere.CreateBinarySet(index_type, binary)


def gen_hnsw_params(params):
    cfg = get_default_build_config(params['metric'])
    return cfg


def gen_diskann_params(params):
    expand_ratio = float(params['key-values']['cacheratio']) / 0.1
    search_cache_budget_gb = int(params['file_size']) * expand_ratio / (1 << 30) / 1.5
    cfg = get_default_build_config(params['metric'])
    cfg[BuildParam.INDEX_PREFIX] = params['prefix']
    cfg[BuildParam.SEARCH_CACHE_BUDGET_GB] = search_cache_budget_gb
    cfg[BuildParam.USE_BFS_CACHE] = constants.USE_BFS_CACHE
    cfg[BuildParam.WARM_UP] = constants.WARM_UP
    return cfg


class TestCloud:
    @pytest.mark.cardinal
    def test_load_hnsw_compatibility(self):
        suffix = '_mem.index.bin'

        index_files = list_files_with_suffix(cloud_index_file_dir, suffix)

        assert len(index_files) > 0

        for index_file in index_files:
            params = parse_file_info(index_file, suffix)
            index = knowhere.CreateIndex(params['index_type'], int(params['version']))
            prepare_params = gen_hnsw_params(params)
            binary = gen_binary_set(params['index_type'], index_file)

            s = index.Deserialize(binary, json.dumps(prepare_params))

            if knowhere.Status(s) != knowhere.Status.success:
                print(f' deserialize {index_file} failed')

            assert knowhere.Status(s) == knowhere.Status.success

    @pytest.mark.cardinal
    def test_load_search_diskann_compatibility(self):
        index_suffix = '_disk.index.bin'

        index_files = list_files_with_suffix(cloud_index_file_dir, index_suffix)

        assert len(index_files) > 0

        for index_file in index_files:
            params = parse_file_info(index_file, index_suffix)
            index = knowhere.CreateIndex(params['index_type'], int(params['version']))
            prepare_params = gen_diskann_params(params)
            s = index.Deserialize(knowhere.GetBinarySet(), json.dumps(prepare_params))

            if knowhere.Status(s) != knowhere.Status.success:
                print(f' deserialize {index_file} failed')

            assert knowhere.Status(s) == knowhere.Status.success
