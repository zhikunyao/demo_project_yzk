import logging
import pytest

LOG_FORMAT = "[%(asctime)s - %(levelname)s - %(name)s]: %(message)s (%(filename)s:%(lineno)s) (%(thread)d:%(threadName)s)"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"
log_name = f"knowhere_ci"
logging.basicConfig(filename=f"/tmp/{log_name}.log",
                    level=logging.INFO, format=LOG_FORMAT, datefmt=DATE_FORMAT)


def pytest_addoption(parser):
    parser.addoption("--timeout", action="store", default=300, help="timeout for search stability test")


@pytest.fixture
def timeout(request):
    return int(request.config.getoption("--timeout"))

