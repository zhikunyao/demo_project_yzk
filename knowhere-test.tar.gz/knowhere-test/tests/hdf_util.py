import constants
from constants import DataClass, MetricType
import h5py
import numpy as np

RAW_DATA_DIR = "/home/data/milvus/raw_data/"
HDF5_DATA_DIR = "/home/caiyd/Data/hdf5/"
HDF5_TRANS_FBIN_DIR = "/home/caiyd/Data/hdf5/newtransfbin/"

# not used at the moment : sift1b/ deep1b/ jaccard/ hamming/
SIFT_SRC_DATA_DIR = RAW_DATA_DIR + "sift1b/"
DEEP_SRC_DATA_DIR = RAW_DATA_DIR + 'deep1b/'
JACCARD_SRC_DATA_DIR = RAW_DATA_DIR + 'jaccard/'
HAMMING_SRC_DATA_DIR = RAW_DATA_DIR + 'hamming/'

SSNPP_DATA_DIR = RAW_DATA_DIR + 'ssnpp-1M-float/'
SSNPP_GROUND_TRUTH = SSNPP_DATA_DIR + 'ssnpp-1M-gt-radius-96237.0'
SSNPP_RANGE_DATA_PATH = SSNPP_DATA_DIR + "FB_ssnpp_database.1M.fbin"
SSNPP_RANGE_QUERY_PATH = SSNPP_DATA_DIR + "FB_ssnpp_public_queries.fbin"

HDF5_SIFT = HDF5_DATA_DIR + "sift-128-euclidean.hdf5"
HDF5_GLOVE = HDF5_DATA_DIR + "glove-200-angular_IP.hdf5"
HDF5_GLOVE_COSINE = HDF5_DATA_DIR + "glove-200-angular.hdf5"
HDF5_SIFT_HAMMING = HDF5_DATA_DIR + "binary/sift-4096-hamming.hdf5"
HDF5_SIFT_JACCARD = HDF5_DATA_DIR + "binary/sift-4096-jaccard.hdf5"

HDF5_SIFT_RANGE = HDF5_DATA_DIR + "1201/" + "sift-128-euclidean-range.hdf5"
HDF5_GLOVE_RANGE = HDF5_DATA_DIR + ""
HDF5_GLOVE_COSINE_RANGE = HDF5_DATA_DIR + "glove-200-angular-range.hdf5"
HDF5_SIFT_HAMMING_RANGE = HDF5_DATA_DIR + "binary/sift-4096-hamming-range.hdf5"
HDF5_SIFT_JACCARD_RANGE = HDF5_DATA_DIR + "binary/sift-4096-hamming-range.hdf5"

HDF5_RAND_DATA_DIR = "/home/caiyd/Data/hdf5/rand/"
HDF5_RAND_L2 = HDF5_RAND_DATA_DIR + "rand-128-l2.hdf5"
HDF5_RAND_IP = HDF5_RAND_DATA_DIR + "rand-128-ip.hdf5"
HDF5_RAND_COSINE = HDF5_RAND_DATA_DIR + "rand-128-cosine.hdf5"
HDF5_RAND_HAMMING = HDF5_RAND_DATA_DIR + "rand-1024-hamming.hdf5"
HDF5_RAND_JACCARD = HDF5_RAND_DATA_DIR + "rand-1024-jaccard.hdf5"

HDF5_RAND_L2_RANGE = HDF5_RAND_DATA_DIR + "rand-128-l2-range.hdf5"
HDF5_RAND_IP_RANGE = HDF5_RAND_DATA_DIR + "rand-128-ip-range.hdf5"
HDF5_RAND_COSINE_RANGE = HDF5_RAND_DATA_DIR + "rand-128-cosine-range.hdf5"
HDF5_RAND_HAMMING_RANGE = HDF5_RAND_DATA_DIR + "rand-1024-hamming-range.hdf5"
HDF5_RAND_JACCARD_RANGE = HDF5_RAND_DATA_DIR + "rand-1024-jaccard-range.hdf5"

DISKANN_SIFT_BIN_FNAME = {
    'base': HDF5_TRANS_FBIN_DIR + 'siftbase1M.fbin',
    'query': HDF5_TRANS_FBIN_DIR + 'siftquery.fbin',
    'groundtruth': HDF5_TRANS_FBIN_DIR + '1M-topk100-gt'
}
DISKANN_GLOVE_BIN_FNAME = {
    'base': HDF5_TRANS_FBIN_DIR + 'glovebase1M.fbin',
    'query': HDF5_TRANS_FBIN_DIR + 'glovequery.fbin',
    'groundtruth': HDF5_TRANS_FBIN_DIR + 'glove1M-topk100-gt'
}
DISKANN_GLOVE_COSINE_BIN_FNAME = {
    'base': HDF5_TRANS_FBIN_DIR + 'GLOVE-cosinebase1M.fbin',
    'query': HDF5_TRANS_FBIN_DIR + 'GLOVE-cosinequery.fbin',
    'groundtruth': HDF5_TRANS_FBIN_DIR + 'GLOVE-cosine1M-topk100-gt'
}

FILE_PREFIX = "binary_"

def get_dim(data_class):
    if data_class == DataClass.SIFT:
        return 128
    if data_class == DataClass.GLOVE:
        return 200
    if data_class in [DataClass.SIFT_HAMMING, DataClass.SIFT_JACCARD]:
        return 4096
    elif data_class == "deep":
        return 96
    elif data_class == "jaccard":
        return 512
    elif data_class == DataClass.KNN_SSNPP256d1M:
        return 256
    else:
        return 0


###############################################################################
### RANDOM DATASET
###############################################################################
def get_rand_dataset(metric_type, is_range=False):
    """ Determine whether hdf5 file exists, and return the content of hdf5 file """
    if metric_type == MetricType.L2:
        if is_range:
            dataset = h5py.File(HDF5_RAND_L2_RANGE)
        else:
            dataset = h5py.File(HDF5_RAND_L2)
    elif metric_type == MetricType.IP:
        if is_range:
            dataset = h5py.File(HDF5_RAND_IP_RANGE)
        else:
            dataset = h5py.File(HDF5_RAND_IP)
    elif metric_type == MetricType.COSINE:
        if is_range:
            dataset = h5py.File(HDF5_RAND_COSINE_RANGE)
        else:
            dataset = h5py.File(HDF5_RAND_COSINE)
    elif metric_type == MetricType.HAMMING:
        if is_range:
            dataset = h5py.File(HDF5_RAND_HAMMING_RANGE)
        else:
            dataset = h5py.File(HDF5_RAND_HAMMING)
    elif metric_type == MetricType.JACCARD:
        if is_range:
            dataset = h5py.File(HDF5_RAND_JACCARD_RANGE)
        else:
            dataset = h5py.File(HDF5_RAND_JACCARD)
    else:
        raise Exception("metric_type: %s not supported" % metric_type)
    return dataset


def get_rand_train_data_array(metric_type):
    ds = get_rand_dataset(metric_type)
    if metric_type in constants.all_binary_metric_types:
        return np.array(ds["train"]).astype(np.int32)
    else:
        return np.array(ds["train"]).astype(np.float32)


def get_rand_test_data_array(metric_type):
    ds = get_rand_dataset(metric_type)
    if metric_type in constants.all_binary_metric_types:
        return np.array(ds["test"]).astype(np.int32)
    else:
        return np.array(ds["test"]).astype(np.float32)


def get_rand_gt_id_array(metric_type):
    ds = get_rand_dataset(metric_type)
    return np.array(ds["neighbors"])


def get_rand_gt_distance_array(metric_type):
    ds = get_rand_dataset(metric_type)
    return np.array(ds["distances"])


# rand range dataset
def get_rand_range_train_data_array(metric_type):
    ds = get_rand_dataset(metric_type, True)
    if metric_type in constants.all_binary_metric_types:
        return np.array(ds["train"]).astype(np.int32)
    else:
        return np.array(ds["train"]).astype(np.float32)


def get_rand_range_test_data_array(metric_type):
    ds = get_rand_dataset(metric_type, True)
    if metric_type in constants.all_binary_metric_types:
        return np.array(ds["test"]).astype(np.int32)
    else:
        return np.array(ds["test"]).astype(np.float32)


def get_rand_range_gt_id_array(metric_type):
    ds = get_rand_dataset(metric_type, True)
    arr = np.array(ds["neighbors"])
    return arr[0]


def get_rand_range_gt_distance_array(metric_type):
    ds = get_rand_dataset(metric_type, True)
    arr = np.array(ds["distances"])
    return arr[0]


def get_rand_range_gt_lims_array(metric_type):
    ds = get_rand_dataset(metric_type, True)
    arr = np.array(ds["lims"])
    return arr[0]


def get_rand_range_radius(metric_type):
    ds = get_rand_dataset(metric_type, True)
    arr = np.array(ds["radius"]).astype(np.float32)
    return arr[0][0].item()


def get_rand_meta_info(metric_type, is_range=False):
    if metric_type in [MetricType.L2, MetricType.IP, MetricType.COSINE]:
        if is_range:
            arr = get_rand_range_train_data_array(metric_type)
            return arr.shape[0], arr.shape[1]
        else:
            arr = get_rand_train_data_array(metric_type)
            return arr.shape[0], arr.shape[1]
    else:
        if is_range:
            arr = get_rand_range_train_data_array(metric_type, True)
            return arr.shape[0], arr.shape[1] * 32
        else:
            arr = get_rand_train_data_array(metric_type, True)
            return arr.shape[0], arr.shape[1] * 32


###############################################################################
### PUBLIC DATASET
###############################################################################
def get_dataset(data_class, is_range=False):
    """ Determine whether hdf5 file exists, and return the content of hdf5 file """
    if data_class == DataClass.SIFT:
        if is_range:
            dataset = h5py.File(HDF5_SIFT_RANGE)
        else:
            dataset = h5py.File(HDF5_SIFT)
    elif data_class == DataClass.GLOVE:
        if is_range:
            dataset = h5py.File(HDF5_GLOVE_RANGE)
        else:
            dataset = h5py.File(HDF5_GLOVE)
    elif data_class == DataClass.GLOVE_COSINE:
        if is_range:
            dataset = h5py.File(HDF5_GLOVE_COSINE_RANGE)
        else:
            dataset = h5py.File(HDF5_GLOVE_COSINE)
    elif data_class == DataClass.SIFT_HAMMING:
        if is_range:
            dataset = h5py.File(HDF5_SIFT_HAMMING_RANGE)
        else:
            dataset = h5py.File(HDF5_SIFT_HAMMING)
    elif data_class == DataClass.SIFT_JACCARD:
        if is_range:
            dataset = h5py.File(HDF5_SIFT_JACCARD_RANGE)
        else:
            dataset = h5py.File(HDF5_SIFT_JACCARD)
    else:
        raise Exception("data_class: %s not supported" % data_class)
    return dataset


def get_metric_type(data_class):
    if data_class == DataClass.SIFT:
        metric_type = MetricType.L2
    elif data_class == DataClass.GLOVE:
        metric_type = MetricType.IP
    elif data_class == DataClass.GLOVE_COSINE:
        metric_type = MetricType.COSINE
    elif data_class == DataClass.SIFT_HAMMING:
        metric_type = MetricType.HAMMING
    elif data_class == DataClass.SIFT_JACCARD:
        metric_type = MetricType.JACCARD
    elif data_class == DataClass.KNN_SSNPP256d1M:
        metric_type = MetricType.L2
    else:
        raise Exception("data_class: %s not supported" % data_class)
    return metric_type


def get_train_data_array(data_class):
    ds = get_dataset(data_class)
    return np.array(ds["train"]).astype(np.float32)


def get_test_data_array(data_class, nq):
    ds = get_dataset(data_class)
    return np.array(ds["test"][:nq]).astype(np.float32)


def get_gt_id_array(data_class):
    ds = get_dataset(data_class)
    return np.array(ds["neighbors"])


def get_gt_distance_array(data_class):
    ds = get_dataset(data_class)
    return np.array(ds["distances"])


# range dataset
def get_range_train_data_array(data_class):
    ds = get_dataset(data_class, True)
    return np.array(ds["train"]).astype(np.float32)


def get_range_test_data_array(data_class, nq):
    ds = get_dataset(data_class, True)
    return np.array(ds["test"][:nq]).astype(np.float32)


def get_range_gt_id_array(data_class):
    ds = get_dataset(data_class, True)
    arr = np.array(ds["neighbors"])
    return arr[0]


def get_range_gt_distance_array(data_class):
    ds = get_dataset(data_class, True)
    arr = np.array(ds["distances"])
    return arr[0]


def get_range_gt_lims_array(data_class):
    ds = get_dataset(data_class, True)
    arr = np.array(ds["lims"])
    return arr[0]


def get_range_radius(data_class):
    ds = get_dataset(data_class, True)
    arr = np.array(ds["radius"]).astype(np.float64)
    return arr[0][0]


def get_meta_info(data_class):
    file = get_file_path(data_class)
    if data_class == DataClass.KNN_SSNPP256d1M:
        info = fbin_meta_info(file)
    else:
        info = hdf5_meta_info(file)
    rows, dim = info[0], info[1]
    return rows, dim


def get_file_path(data_class):
    if data_class == DataClass.SIFT:
        file = HDF5_SIFT
    elif data_class == DataClass.GLOVE:
        file = HDF5_GLOVE
    elif data_class == DataClass.GLOVE_COSINE:
        file = HDF5_GLOVE_COSINE
    elif data_class == DataClass.SIFT_HAMMING:
        file = HDF5_SIFT_HAMMING
    elif data_class == DataClass.SIFT_JACCARD:
        file = HDF5_SIFT_JACCARD
    elif data_class == DataClass.KNN_SSNPP256d1M:
        file = SSNPP_RANGE_DATA_PATH
    else:
        raise Exception("data_class: %s not supported" % data_class)
    return file


def hdf5_meta_info(fname_h5):
    meta_dict = {}
    with h5py.File(fname_h5) as f:
        keys = f.keys()
        for key in keys:
            train_shape = f[key].shape
            meta_dict[key] = train_shape
    return meta_dict["train"]


def fbin_meta_info(fname):
    with open(fname, "rb") as f:
        nvecs, dim = np.fromfile(f, count=2, dtype=np.uint32)
        f.close()
    return (nvecs, dim)
